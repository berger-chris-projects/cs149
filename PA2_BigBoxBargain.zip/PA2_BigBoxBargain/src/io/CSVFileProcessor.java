package io;

import java.io.File;
import java.io.IOException;

/**
 * Utilizes comma-separated-value files for accessing data on objects.
 * 
 * @author Vanessa P
 * @version 10/30/2023
 */

public class CSVFileProcessor extends FileProcessor {

    /**
     * Explicit Value Constructor.
     * 
     * @param file the File object for processing
     */

    public CSVFileProcessor(File file) {
        super(file);
    }

    /**
     * FileIdentifier Value Constructor.
     * 
     * @param identifier the identifiable object for a file
     */

    public CSVFileProcessor(FileIdentifier identifier) {
        super(identifier);
    }

    /**
     * From-Scratch Value Constructor.
     * 
     * @param fileName the new file's name
     */

    public CSVFileProcessor(String fileName) {
        super(fileName);
    }

    /**
     * The inherited data decryption method.
     * 
     * @param line the String to be decrypted
     * @return the decrypted line
     */

    @Override
    protected String decrypt(String line) {
        return line;
    }

    /**
     * The inherited data encryption method.
     * 
     * @param line the String to be encrypted
     * @retrun the encrypted line
     */

    @Override
    protected String encrypt(String line) {
        return line;
    }

    /**
     * Updates the given objects with the data from this CSV file.
     * 
     * @param objects the CSVRepresentable objects to be initialized
     * @throws IOException
     */

    public void read(CSVRepresentable... objects) throws IOException {
        int i = 0;
        String[] strarr = super.readLines();
        for (String str : strarr) {
            objects[i].fromCSV(str);
            i++;
        }
    }

    /**
     * Writes the given objects to this CSV file.
     * 
     * @param objects the initialized CSVRepresentable objects
     * @throws IOException
     */

    public void write(CSVRepresentable... objects) throws IOException {
        String[] strarr = new String[objects.length];
        for (int i = 0; i < objects.length; i++) {
            strarr[i] = objects[i].toCSV();
        }
        super.writeLines(strarr);
    }
}
