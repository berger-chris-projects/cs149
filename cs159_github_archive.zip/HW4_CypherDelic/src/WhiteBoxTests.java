import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class WhiteBoxTests {

    @Test
    void charOfTest() {
        assertEquals('J', PhraseCypher.charOf(10));
        assertEquals('M', PhraseCypher.charOf(13));
        assertEquals('U', PhraseCypher.charOf(21));
        assertEquals((char) 0, PhraseCypher.charOf(-100));
        assertEquals((char) 0, PhraseCypher.charOf(100));
    }

    @Test
    void valueOfTest() {
        assertEquals(10, PhraseCypher.valueOf('J'));
        assertEquals(13, PhraseCypher.valueOf('M'));
        assertEquals(21, PhraseCypher.valueOf('U'));
    }

    @Test
    void constructor_IllegalArgumentException() {

        try {
            new PhraseCypher("THE QUICK BROWN FOX JUMPS OVER THE LAZY DOGGY");
        } catch (IllegalArgumentException iae) {
            fail("An IllegalArgumentException should not have been thrown (but was).");
        }

        try {
            new PhraseCypher("THE QUICK BROWN FOX");
            fail("An IllegalArgumentException should have been thrown (but wasn't).");
        } catch (IllegalArgumentException iae) {
            // This should happen!
        }

        try {
            new PhraseCypher(" 1ABCDEFGHIJKLMNOPQRSTUVWXYZ");
            fail("An IllegalArgumentException should have been thrown (but wasn't).");
        } catch (IllegalArgumentException iae) {
            // This should happen
        }
    }

    @Test
    void encryptTest() {
        PhraseCypher cypher;
                 //           1         2         3         4
                 // 012345678901234567890123456789012345678901234
        String s = "THE QUICK BROWN FOX JUMPS OVER THE LAZY DOGGY";
        cypher = new PhraseCypher(s);
        {
            int[] actual = cypher.encrypt("THE");
            int[] expected = { 0, 1, 2 };
            assertArrayEquals(expected, actual);
        }
        {
            int[] actual = cypher.encrypt("FOR NOW");
            // F O R | N O W
            int[] expected = { 16, 12, 11, 3, 14, 12, 13 };

            assertArrayEquals(expected, actual);
        }
        {
            int[] actual = cypher.encrypt("JMU DUKES");
            // J M U | D U K E S
            int[] expected = { 20, 22, 5, 3, 40, 5, 8, 2, 24 };
            assertArrayEquals(expected, actual);
        }
        {
            int[] actual = cypher.encrypt("");
            int[] expected = new int[0];
            assertArrayEquals(expected, actual);
        }
        {
            int[] actual = cypher.encrypt("the!");
            int[] expected = { 0, 1, 2, -1 };
            assertArrayEquals(expected, actual);
        }
    }

    @Test
    void decryptTest() {
        PhraseCypher cypher;
        // 1 2 3 4
        // 012345678901234567890123456789012345678901234
        cypher = new PhraseCypher(
                "THE QUICK BROWN FOX JUMPS OVER THE LAZY DOGGY");
        {
            String actual = cypher.decrypt(new int[] { 0, 1, 2 });
            String expected = "THE";
            assertEquals(expected, actual);
        }
        {
            String actual = cypher
                    .decrypt(new int[] { 16, 12, 11, 3, 14, 17, 13 });
            String expected = "FOR NOW";
            assertEquals(expected, actual);
        }
        {
            String actual = cypher
                    .decrypt(new int[] { 20, 22, 5, 3, 40, 5, 8, 2, 24 });
            String expected = "JMU DUKES";
            assertEquals(expected, actual);
        }
        {
            String actual = cypher.decrypt(new int[0]);
            String expected = "";
            assertEquals(expected, actual);
        }
    }

}
