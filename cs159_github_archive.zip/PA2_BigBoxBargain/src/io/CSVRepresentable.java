package io;

import java.util.Scanner;

/**
 * Outlines the comma-separated-value representation at Big Box Bargains.
 * 
 * @author Vanessa P
 * @version 10/30/2023
 */

public interface CSVRepresentable {

    /**
     * Tokenizes the given String and returns the scanner object for later
     * tokenizing.
     * 
     * @param s the CSV file string of an object
     * @return the Scanner object to use for later scanning
     */
    Scanner fromCSV(String s);

    /**
     * Formats an object's fields as a comma-separated value file.
     * 
     * @return the finalized String of fields with a comma delimiter
     */
    String toCSV();
}
