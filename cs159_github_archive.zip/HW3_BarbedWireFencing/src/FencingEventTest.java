
public class FencingEventTest {
	
	public static void main(String[] args) {
		
		FencingEvent event;
		
		event = FencingEvent.FOIL;
		BladePart[] foilBladeT = {BladePart.TIP};
		BladePart[] foilBladeF = {BladePart.EDGE};
		BodyPart[] foilBodyT = {BodyPart.TORSO, BodyPart.CROTCH};
		BodyPart[] foilBodyF = {BodyPart.HEAD, BodyPart.ARMS, BodyPart.HANDS, BodyPart.LEGS};
		Test.forEqual(500, event.getMaximumWeight(), event.toString() + " maximum weight");
		testIsLegalBladePart(event, foilBladeT, foilBladeF);
		testIsOnTarget(event, foilBodyT, foilBodyF);
		testIsScoringTouch(event, foilBladeT, foilBladeF, foilBodyT, foilBodyF);
		
		event = FencingEvent.EPEE;
		BladePart[] epeeBladeT = {BladePart.TIP};
		BladePart[] epeeBladeF = {BladePart.EDGE};
		BodyPart[] epeeBodyT = {BodyPart.HEAD, BodyPart.ARMS, BodyPart.HANDS, BodyPart.TORSO, BodyPart.CROTCH,  BodyPart.LEGS};
		BodyPart[] epeeBodyF = {};
		Test.forEqual(775, event.getMaximumWeight(), event.toString() + " maximum weight");
		testIsLegalBladePart(event, epeeBladeT, epeeBladeF);
		testIsOnTarget(event, epeeBodyT, epeeBodyF);
		testIsScoringTouch(event, epeeBladeT, epeeBladeF, epeeBodyT, epeeBodyF);
		
		event = FencingEvent.SABRE;
		BladePart[] sabreBladeT = {BladePart.TIP, BladePart.EDGE};
		BladePart[] sabreBladeF = {};
		BodyPart[] sabreBodyT = {BodyPart.HEAD, BodyPart.ARMS, BodyPart.TORSO};
		BodyPart[] sabreBodyF = {BodyPart.HANDS, BodyPart.CROTCH,  BodyPart.LEGS};
		Test.forEqual(500, event.getMaximumWeight(), event.toString() + " maximum weight");
		testIsLegalBladePart(event, sabreBladeT, sabreBladeF);
		testIsOnTarget(event, sabreBodyT, sabreBodyF);
		testIsScoringTouch(event, sabreBladeT, sabreBladeF, sabreBodyT, sabreBodyF);
		
		System.out.println(Test.getSummary());
		
	}
	
	private static void testIsLegalBladePart(FencingEvent event,
			BladePart[] bladeT, BladePart[] bladeF) {

		// Good blade parts
		for (int i=0; i<bladeT.length; i++) {
			String description = event.toString() + " " + bladeT[i].toString();
			Test.forTrue(event.isLegalBladePart(bladeT[i]), description);
		}
		
		// Bad blade parts
		for (int i=0; i<bladeF.length; i++) {
			String description = event.toString() + " " + bladeF[i].toString();
			Test.forFalse(event.isLegalBladePart(bladeF[i]), description);
		}
	}

	private static void testIsOnTarget(FencingEvent event,
			BodyPart[] bodyT, BodyPart[] bodyF) {

		// Good body parts
		for (int i=0; i<bodyT.length; i++) {
			String description = event.toString() + " " + bodyT[i].toString();
			Test.forTrue(event.isOnTarget(bodyT[i]), description);
		}
		
		// Bad body parts
		for (int i=0; i<bodyF.length; i++) {
			String description = event + " " + bodyF[i].toString();
			Test.forFalse(event.isOnTarget(bodyF[i]), description);
		}
	}
	
	private static void testIsScoringTouch(FencingEvent event,
			BladePart[] bladeT, BladePart[] bladeF, 
			BodyPart[] bodyT, BodyPart[] bodyF) {
		
		
		// Good blade and good body
		for (int i=0; i<bladeT.length; i++) {
			for (int j=0; j<bodyT.length; j++) {
				String description = event + " " + bladeT[i] + " on " + bodyT[j].toString();
				Test.forTrue(event.isScoringTouch(bladeT[i], bodyT[j]), description);
			}
		}
		
		// Bad blade, bad body
		for (int i=0; i<bladeF.length; i++) {
			for (int j=0; j<bodyF.length; j++) {
				String description = event + " " + bladeF[i] + " on " + bodyF[j].toString();
				Test.forFalse(event.isScoringTouch(bladeF[i], bodyF[j]), description);
			}
		}
		
		// Good blade and bad body
		for (int i=0; i<bladeT.length; i++) {
			for (int j=0; j<bodyF.length; j++) {
				String description = event + " " + bladeT[i] + " on " + bodyF[j].toString();
				Test.forFalse(event.isScoringTouch(bladeT[i], bodyF[j]), description);
			}
		}
		
		// Bad blade, good body
		for (int i=0; i<bladeF.length; i++) {
			for (int j=0; j<bodyT.length; j++) {
				String description = event + " " + bladeF[i] + " on " + bodyT[j].toString();
				Test.forFalse(event.isScoringTouch(bladeF[i], bodyT[j]), description);
			}
		}
	}
}
