/**
 * Tests random inputs into PhraseCypher's class methods.
 * 
 * @author Chris Berger
 * @version 9/25/2023
 */
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class RandomTests {

    /**
     * Tests the charOf method with unusual/complex inputs.
     */
    @Test

    public void charOfTestA() {
        assertEquals('H', PhraseCypher.charOf(8));
        assertEquals('Y', PhraseCypher.charOf(25));
        assertEquals((char) 0, PhraseCypher.charOf((64 / 2)));
        assertEquals((char) ' ', PhraseCypher.charOf(0));
        assertEquals((char) 0, PhraseCypher.charOf(-999999));

    }

    /**
     * Tests the valueOf method with unusual/complex inputs.
     */
    @Test

    public void valueOfTestA() {
        assertEquals(10, PhraseCypher.valueOf('J'));
        assertEquals(13, PhraseCypher.valueOf('M'));
        assertEquals(21, PhraseCypher.valueOf('U'));
        assertEquals(-1, PhraseCypher.valueOf((char) '{'));
    }

    /**
     * Tests the decrypt method with unusual/complex methods.
     */
    @Test

    public void decryptTestA() {
        PhraseCypher cyffer = new PhraseCypher(
                "THE QUICK BROWN FOX JUMPS OVER THE LAZY DOGGY");
              // 0  _     _1    _    2    _    3   _    _4
        {     // 012345678901234567890123456789012345678901234
            String actual = cyffer.decrypt(new int[] { 6, 7, 8, 3, 10 });
            String expected = "ICK B";
            assertEquals(expected, actual);
        }
        {
            String actual = cyffer
                    .decrypt(new int[] { 16, 12, 11, 3, 3, 3, 14, 17, 13 });
            String expected = "FOR   NOW";
            assertEquals(expected, actual);
        }
        {
            String actual = cyffer.decrypt(new int[] { 35, 12, 12, 8, 3, 36,
                    0, 3, 22, 2, 3, 13, 1, 2, 14, 3, 6, 3, 0, 36, 35, 8, 3, 0,
                    12, 3, 38, 12, 5 });
            String expected = "LOOK AT ME WHEN I TALK TO YOU";
            assertEquals(expected, actual);
        }
        {
            String actual = cyffer.decrypt(new int[0]);
            String expected = "";
            assertEquals(expected, actual);
        }
        {
            String actual = cyffer.decrypt(new int[] { 2, 36, 0, 3, 22, 38, 3,
                    24, 1, 12, 11, 0, 24 });
            String expected = "EAT MY SHORTS";
            assertEquals(expected, actual);
        }
    }

    /**
     * Tests the encrypt method with unusual.complex methods.
     */
    @Test

    public void encryptTestA() {
        PhraseCypher sipher = new PhraseCypher(
                "THE QUICK BROWN FOX JUMPS OVER THE LAZY DOGGY");
              // 012345678901234567890123456789012345678901234
        {     // 0  _     _1    _   _2    _    3   _    _4
            int[] actual = sipher.encrypt("FUCK YOU ");
            int[] expected = { 16, 5, 7, 8, 3, 38, 12, 5, 3 };
            assertArrayEquals(expected, actual);
        }
        {
            int[] actual = sipher.encrypt("?/ EAT");
            int[] expected = { -1, -1, 3, 2, 36, 0 };
            assertArrayEquals(expected, actual);
        }
        {
            int[] actual = sipher.encrypt(" ACCUMULATIN{} ");
            int[] expected = { 3, 36, 7, 7, 5, 22, 5, 35, 36, 0, 6, 14, -1,
                    -1, 3 };
            assertArrayEquals(expected, actual);
        }
        {
            int[] actual = sipher.encrypt("");
            int[] expected = new int[0];
            assertArrayEquals(expected, actual);
        }
        {
            int[] actual = sipher.encrypt("the!");
            int[] expected = { 0, 1, 2, -1 };
            assertArrayEquals(expected, actual);
        }
    }
}