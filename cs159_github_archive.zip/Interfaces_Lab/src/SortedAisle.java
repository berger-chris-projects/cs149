import java.util.Collections;
import java.util.Random;

public class SortedAisle extends Aisle {

    
    public SortedAisle(Random generator) {
        super(generator);
    }
    
    @Override
    public void addCustomer(Customer customer) {
        super.addCustomer(customer);
        Collections.sort(this.line);
    }
}
