package io;

import java.io.File;
import java.util.Scanner;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * An abstracted file processing class that can read and write files.
 * 
 * @author Vanessa P
 * @version 10/30/2023
 */



public abstract class FileProcessor {
    private File file;

    /**
     * Explicit Value Constructor
     * 
     * @param file the file object for processing
     */
    public FileProcessor(File file) {
        this.file = file;
    }

    /**
     * FileIdentifier Value Constructor.
     * 
     * @param identifier the file's identifiable String
     */
    public FileProcessor(FileIdentifier identifier) {
        this.file = new File(identifier.toString());
    }

    /**
     * From-scratch Value Constructor.
     * 
     * @param fileName the new file for processing
     */
    public FileProcessor(String fileName) {
        this.file = new File(fileName);
    }

    /**
     * Abstract subclass decryption.
     * 
     * @param line the string to be decrypted
     * @return the newly decrypted data
     */

    protected abstract String decrypt(String line);

    /**
     * Abstract subclass encryption.
     * 
     * @param line the string to be encrypted
     * @return the newly encrypted data
     */

    protected abstract String encrypt(String line);

    /**
     * Decrypts this file's records into operable Strings.
     * 
     * @return the decrypted and
     * @throws IOException
     */

    protected String[] readLines() throws IOException {
        Scanner read;
        String[] lines;
        int a = 0, b = 0;

        read = new Scanner(file);
        // read.UseDelimiter("\n") goes here??
        a = read.nextInt();
        lines = new String[a];
        while (read.hasNextLine() && b < lines.length) {
            String d = decrypt(read.nextLine());
            lines[b] = d;
            b++;
        }
        read.close();
        return lines;
    }

    /**
     * Encrypts the provided Strings into this file's records.
     * 
     * @param lines the comma-seperated value records as Strings
     * @throws IOException
     */

    protected void writeLines(String[] lines) throws IOException {
        PrintWriter pw;

        pw = new PrintWriter(file);
        pw.write(lines.length + "\n");
        for (int i = 0; i < lines.length; i++) {
            pw.write(encrypt(lines[i]) + "\n");
        }
        pw.close();
    }
}
