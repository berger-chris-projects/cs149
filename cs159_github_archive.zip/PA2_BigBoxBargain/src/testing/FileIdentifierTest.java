/**
 * JUnit Test class for the (CSVRepresentable) FileIdentifier functionality.
 * 
 * @author Vanessa P
 * @version 10/30/2023
 */

package testing;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import io.FileIdentifier;
import membership.VIPAccount;

class FileIdentifierTest {

    /**
     * JUnit round trip test case for the implemented fromCSV() and toCSV()
     * methods.
     */

    @Test
    public void fromCSVTest() {
        FileIdentifier fi1, fi2, fi3, fi4;
        fi1 = new FileIdentifier("poopoo", "txt");
        fi2 = new FileIdentifier("aCcOuNtS", "bbb");
        fi3 = new FileIdentifier("nonexistent", "nan");
        fi4 = new FileIdentifier("file", "ext");
        String s1 = "poopoo,txt", s2 = "aCcOuNtS,bbb", s3 = "nonexistent,nan",
                s4 = "file,ext";

        fi1.fromCSV(s1);
        fi2.fromCSV(s2);
        fi3.fromCSV(s3);
        fi4.fromCSV(s4);

        assertEquals(s1, fi1.toCSV());
        assertEquals(s2, fi2.toCSV());
        assertEquals(s3, fi3.toCSV());
        assertEquals(s4, fi4.toCSV());
    }

    /**
     * JUnit test case for the toString() method.
     */

    @Test
    public void toStringTest() {
        FileIdentifier fi1, fi2, fi3, fi4;
        fi1 = new FileIdentifier("poopoo", "txt");
        fi2 = new FileIdentifier("aCcOuNtS", "bbb");
        fi3 = new FileIdentifier("nonexistent", "nan");
        fi4 = new FileIdentifier("file", "ext");
        String s1 = "poopoo.txt", s2 = "aCcOuNtS.bbb", s3 = "nonexistent.nan",
                s4 = "file.ext";

        assertEquals(s1, fi1.toString());
        assertEquals(s2, fi2.toString());
        assertEquals(s3, fi3.toString());
        assertEquals(s4, fi4.toString());
    }
}
