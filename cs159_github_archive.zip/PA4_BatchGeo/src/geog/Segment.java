package geog;

import java.util.Scanner;

/**
 * Contains information on a segment of a Street object in BatchGeo.
 * 
 * @author Vanessa P
 * @version 12/1/23
 */

public class Segment {
    private double length;
    private Location highLocation;
    private Location lowLocation;
    private int highNumber;
    private int lowNumber;
    private String id;
    private String type;

    /**
     * Default Value Constructor.
     */

    public Segment() {
        this.length = 0.00;
        this.highLocation = new Location(0.00, 0.00);
        this.lowLocation = new Location(0.00, 0.00);
        this.highNumber = 0;
        this.lowNumber = 0;
        this.id = null;
        this.type = null;
    }

    /**
     * Determines if this segment has a given house number.
     * 
     * @param number the house number
     * @return whether the house is on this segment
     */

    public boolean contains(int number) {
        return ((number >= lowNumber) && (number <= highNumber));
    }

    /**
     * Represents a given house as a coordinate location.
     * 
     * @param number the house number to interpolate
     * @return the OnSegmentLocation object of the given number
     */

    public OnSegmentLocation interpolate(int number) {
        if (!this.contains(number)) {
            return null;
        }
        double m = (number - lowNumber) / (highNumber - lowNumber);
        double lon = (1 - m) * lowLocation.getLongitude()
                + m * highLocation.getLongitude();
        double lat = (1 - m) * lowLocation.getLatitude()
                + m * highLocation.getLatitude();
        OnSegmentLocation osl = new OnSegmentLocation(id, lon, lat);
        return osl;
    }

    /**
     * Derives this street segment's values from a given string.
     * 
     * @param line this object's attributes, seperated by tabs
     * @return the object's identifiable string
     */

    public String fromTSV(String line) {
        Scanner read = new Scanner(line);
        read.useDelimiter("\t");
        try {
            id = read.next();
            double lowLong = read.nextDouble();
            double lowLat = read.nextDouble();
            lowLocation = new Location(lowLong, lowLat);
            double highLong = read.nextDouble();
            double highLat = read.nextDouble();
            highLocation = new Location(highLong, highLat);
            length = read.nextDouble();
            type = read.next();
            lowNumber = read.nextInt();
            highNumber = read.nextInt();
        } catch (Exception e) {
            System.out.println(e);
        }
        read.close();
        return id;
    }

    /**
     * Provides this segment's length.
     * 
     * @return the length of this street segment (in km)
     */

    public double getLength() {
        return length;
    }

    /**
     * Provides this segment's TIGER road type code.
     * 
     * @return the identifiable TIGER code for this street segment
     */

    public String getType() {
        return type;
    }
}
