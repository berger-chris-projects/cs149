/**
 * The fixed enumeration of body parts counted in fencing.
 * 
 * @author Chris Berger
 * @version 9/22/2023
 */
public enum BodyPart {
    HEAD, ARMS, HANDS, TORSO, CROTCH, LEGS
}
