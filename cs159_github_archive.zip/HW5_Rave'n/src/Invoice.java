import java.util.ArrayList;

/**
 * Represents a financial invoice of one or more orders.
 * 
 * @author Vanessa
 * @version 10/2/2023
 */
public class Invoice {

    private ArrayList<Order> orders;

    /**
     * Explicit Value Constructor.
     */
    public Invoice() {
        this.orders = new ArrayList<Order>();
    }

    /**
     * Appends the order to the invoice.
     * 
     * @param order an order of items
     */

    public void addOrder(Order order) {
        this.orders.add(order);
    }

    /**
     * Retrieves the order at the provided orders index.
     * 
     * @param i the index of the desired order
     * @return the order object
     */

    public Order getOrder(int i) {
        if (i < 0 || i >= this.orders.size()) {
            return null;
        }
        return this.orders.get(i);
    }

    /**
     * Calculates the total cost of this invoice.
     * 
     * @return total price in dollars and cents
     */
    public double getPrice() {
        double p = 0.00;
        for (int a = 0; a < this.orders.size(); a++) {
            p += this.orders.get(a).getPrice();
        }
        return p;
    }

    /**
     * Calculates the total people that can get one item from each order.
     * 
     * @return the minimum number of people that can get at least one serving
     */

    public int getServes() {
        if (this.size() == 0) {
            return 0;
        }
        int minimum = this.orders.get(0).getServes();
        for (int s = 0; s < this.orders.size(); s++) {
            int compare = orders.get(s).getServes();
            if (compare < minimum) {
                minimum = compare;
            }
        }
        return minimum;
    }

    /**
     * Returns the total number of orders in this invoice.
     * 
     * @return the size of the orders attribute
     */

    public int size() {
        return this.orders.size();
    }

}
