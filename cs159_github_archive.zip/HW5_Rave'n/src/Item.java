/**
 * Represents the activity/food at a CS party and its cost for the people it
 * serves.
 * 
 * @author Vanessa
 * @version 10/2/2023
 */

public class Item {
    private double price;
    private int serves;
    private String description;

    /**
     * Explicit Value Constructor.
     * 
     * @param description the String representing this item formatted as
     * specified
     * @param serves the amount of servings of one item
     * @param price the price in dollars and cents of one item
     */
    public Item(String description, int serves, double price) {
        this.description = description;
        this.serves = serves;
        this.price = price;
    }

    /**
     * Duplicate Value Constructor.
     * 
     * @param other Item the other Item object being duplicated
     */
    public Item(Item other) {
        Item o = new Item(other.description, other.serves, other.price);
        this.description = o.description;
        this.serves = o.serves;
        this.price = o.price;
    }

    /**
     * Provides the item's description.
     * 
     * @return the description String
     */
    public String getDescription() {
        return this.description;
    }

    /**
     * Provides the item's price.
     * 
     * @return the price double
     */
    public double getPrice() {
        return this.price;
    }

    /**
     * Provides the item's servings count.
     * 
     * @return the amount of servings for one item
     */
    public int getServes() {
        return this.serves;
    }

    /**
     * Changes the item's description.
     * 
     * @param description it's new description String
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * Changes the cost per item.
     * 
     * @param price it's new price
     */
    public void setPrice(double price) {
        this.price = price;
    }

    /**
     * Changes the number of people one item serves.
     * 
     * @param serves it's new servings per item
     */
    public void setServes(int serves) {
        this.serves = serves;
    }

    /**
     * Formats the instance attributes of an object as follows.
     * 
     * @return String the formatted String
     */
    public String toString() {
        return String.format("%s for %d at $%5.2f", this.getDescription(),
                this.getServes(), this.getPrice());
    }

}
