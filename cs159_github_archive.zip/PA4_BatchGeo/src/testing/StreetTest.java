package testing;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import geog.*;
import java.util.*;

class StreetTest {

	private static final double TOL = 0.01;
	
	@Test
	void geocode() {
		Street hill = new Street("Hill Dr");
		Segment seg;
		String id;
		
		seg = new Segment();
		id = seg.fromTSV("79916285	-78.403297	+38.663495	-78.406971	+38.663408	0.4119990	A41	165	387");
		hill.add(seg);
		
		seg = new Segment();
		id = seg.fromTSV("79911762	-78.516655	+38.581942	-78.517964	+38.580308	0.2143800	A41	150	303");
		hill.add(seg);
		
		seg = new Segment();
		id = seg.fromTSV("79909425	-78.517964	+38.580308	-78.519283	+38.578855	0.1981150	A41	305	359");
		hill.add(seg);

		List<OnSegmentLocation> locations = hill.geocode(158);
		assertEquals(1, locations.size());
		OnSegmentLocation loc = locations.get(0);
		
		assertEquals(-78.516723, loc.getLongitude(), TOL);
		assertEquals( 38.581857, loc.getLatitude(), TOL);

		locations = hill.geocode(300);
		assertEquals(2, locations.size());
		
		Collections.sort(locations);
		assertEquals(-78.517938, locations.get(0).getLongitude(), TOL);
		assertEquals( 38.580340, locations.get(0).getLatitude(), TOL);

		assertEquals(-78.405531, locations.get(1).getLongitude(), TOL);
		assertEquals( 38.663442, locations.get(1).getLatitude(), TOL);
		
	}

}
