package brushes;
/**
 * A Teethbrush data type that is more functional.
 * 
 * @author Vanessa P
 * @version 10/13/2023
 */

public class ElectricTeethbrush extends Teethbrush {

    private static final double BASE_BODY_COST = 5.00;
    private static final double RECHARGEABLE_UPCHARGE = 20.00;
    private static final double ULTRASONIC_UPCHARGE = 10.00;
    private static final int NUMBER_OF_HEADS = 5;

    private boolean rechargeable;
    private boolean ultrasonic;

    /**
     * Explicit Value Constructor.
     * 
     * @param model this brush's model name
     * @param hardness the bristles' stiffness
     * @param polished rounded bristles (or not)
     * @param rechargeable 'rechargeable' device (or not)
     * @param ultrasonic 'ultrasonic' cleaning (or not)
     */

    public ElectricTeethbrush(String model, int hardness, boolean polished,
            boolean rechargeable, boolean ultrasonic) {
        super(model, hardness, polished);
        this.rechargeable = rechargeable;
        this.ultrasonic = ultrasonic;
    }

    /**
     * The dollar and cents price of this specific brush.
     * 
     * @return the cost of this electric brush
     */

    @Override
    public double cost() {
        double c = (NUMBER_OF_HEADS * super.cost()) + BASE_BODY_COST;
        if (this.isRechargeable()) {
            c += RECHARGEABLE_UPCHARGE;
        }
        if (this.isUltrasonic()) {
            c += ULTRASONIC_UPCHARGE;
        }
        return c;
    }

    /**
     * Returns whether the brush's battery is rechargeable.
     * 
     * @return rechargeable battery (or not)
     */

    public boolean isRechargeable() {
        return this.rechargeable;
    }

    /**
     * Returns whether the brush uses ultrasonic cleaning.
     * 
     * @return ultrasonic cleaning (or not)
     */

    public boolean isUltrasonic() {
        return this.ultrasonic;
    }
}