package testing;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import geog.*;
import geog.io.MapReader;

import java.io.*;
import java.util.*;

class MapReaderTest {

	private static final double TOL = 0.01;
	
	@Test
	void readSegmentBase() throws IOException {
		Map<String, Segment> segments = MapReader.readSegments("tiny.seg");
		
		assertEquals(7, segments.size());
		
		Segment seg = segments.get("78833402");
		assertTrue(seg.contains(680));
		assertEquals(-79.112767, seg.interpolate(680).getLongitude(), TOL);
		assertEquals( 38.147076, seg.interpolate(680).getLatitude(), TOL);
		
		seg = segments.get("79916285");
		assertTrue(seg.contains(300));
		assertEquals(-78.405531, seg.interpolate(300).getLongitude(), TOL);
		assertEquals( 38.663442, seg.interpolate(300).getLatitude(), TOL);
	}

	@Test
	void readStreetBase() throws IOException {
		Map<String, Segment> segments = MapReader.readSegments("tiny.seg");
		Map<String, Street> streets = MapReader.readStreets("tiny.str", segments);
		
		Street street = streets.get("Creek Loop");
		List<OnSegmentLocation> locations = street.geocode(205);
		assertEquals(1, locations.size());
		
		OnSegmentLocation loc = locations.get(0);
		assertEquals(-78.935377, loc.getLongitude(), TOL);
		assertEquals( 37.875057, loc.getLatitude(), TOL);
	}
}
