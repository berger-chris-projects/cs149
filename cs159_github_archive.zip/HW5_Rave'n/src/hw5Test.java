import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class hw5Test { // All these tests are unfinished :/
    
    @Test
    public void addOrderTest() {
        Invoice inv = new Invoice();
        Invoice vni = new Invoice();
        assertEquals(inv.size(), 0);
        vni.addOrder(new Order(4, new Item("Papa John's", 8, 13.99)));
        inv.addOrder(new Order(vni.size(), new Item("Natural Light", 12, inv.size())));
        assertEquals(inv.size(), vni.size());
        inv.addOrder(new Order(((vni.size()) + 9), new Item("Fucksticks", 3, 4.20)));
        assertEquals((Math.sqrt(vni.size() + 3)), inv.size());
    }

    @Test
    public void getOrderTest() {
        Invoice invoice = new Invoice();
        Order o1 = new Order(12, new Item("Orville's", 5, 9.99));
        Order o2 = new Order(0, new Item("fuck you", -1, 4.2));
        Order o3 = new Order(o1);
        invoice.addOrder(o1);
        Invoice eciovni = invoice;
        eciovni.addOrder(o3);
        assertEquals(eciovni.getOrder(0), invoice.getOrder(0));
        Invoice voicein = eciovni;
        voicein.addOrder(o2);
        voicein.addOrder(o3);
        assertEquals(voicein.getOrder(0), o2);
        assertEquals(voicein.getOrder(1), o1);
        assertEquals(voicein.getOrder(99), null);
        Invoice shutup = new Invoice();
        assertEquals(shutup.getOrder(1), null);
        assertEquals(invoice.getOrder(10), eciovni.getOrder(10034));
        assertEquals(voicein.getOrder(0), eciovni.getOrder(0));
    }

    @Test
    public void getPriceTest() {
        Invoice i1 = new Invoice();
        Invoice i2 = i1;
        Invoice i3 = new Invoice();
        Invoice iN = i2;
        assertEquals(i3.getPrice(), 0.00);
        i1.addOrder(new Order(3, new Item("Chicken Strips Party Platter", 15, 20.99)));
        i2.addOrder(new Order(((i1.size()) + 3), new Item("Slushie", 1, 3.49)));
        assertEquals(iN.getPrice(), i2.getPrice());
        assertEquals(i1.getPrice(), i2.getPrice());
        
    }

    @Test
    public void getServesTest() {
        Invoice i1 = new Invoice();
        Invoice i2 = i1;
        Invoice i3 = new Invoice();
        Invoice iN = i2;
        assertEquals(i1.getServes(), 0);
        assertEquals(iN.size(), 0);
        i2.addOrder(new Order(3, new Item("Chicken Strips Party Platter", 15, 20.99)));
        i3.addOrder(new Order(5, new Item("Chicken Strips", 3, 9.00)));
        iN.addOrder(new Order(((i2.size()) + 9), new Item("Fucksticks", 5, 4.20)));
        assertEquals(i1.getServes(), 0);
        assertEquals(i2.getServes(), 45);
        assertEquals(i3.getServes(), 15);
        assertEquals(iN.getServes(), 50);
        i1.addOrder(i3.getOrder(0));
        i1.addOrder(iN.getOrder(0));
        assertEquals(i1.getServes(), 15);
    }

    @Test
    public void sizeTest() {
         Invoice invoice = new Invoice();
         Invoice eciovni = new Invoice();
         Invoice voicein = new Invoice();
         Invoice shutup = invoice;
         
         
    }

}
