/**
 * Test class for Pricer.java.
 * 
 * @author Chris Berger
 * @version 9/13/2023
 */
public class Test {

    /**
     * Test method for expected and equal values of type double.
     * 
     * @param expected the expected result
     * @param actual the actual calculated result
     * @param tolerance the margin of error
     * @param description a description of the test
     * @return true if doubles are equal, false otherwise
     */
    public static boolean forEqualDoubles(double expected, double actual,
            double tolerance, String description) {
        if (Math.abs((actual - expected)) > tolerance) {
            System.out.printf("%s Expected: %f, Actual: %f\n", description,
                    expected, actual);
            return false;
        } else {
            return true;
        }
    }

    /**
     * Display an alert if the actual int value is not equal to the expected
     * value.
     *
     * @param expected The expected value
     * @param actual The actual value
     * @param description A description of the test
     * @return true if the two are equal; false otherwise
     */
    public static boolean forEqualInts(int expected, int actual,
            String description) {
        if (expected != actual) {
            System.out.printf("%s Expected: %d, Actual: %d\n", description,
                    expected, actual);
            return false;
        } else {
            return true;
        }
    }

    /**
     * Test class for expected vs. equal values with type String.
     * 
     * @param expected the expected value
     * @param actual the actual calculated value
     * @param description the description of the test
     * @return true if strings are equal, false otherwise
     */
    public static boolean forEqualStrings(String expected, String actual,
            String description) {
        if (!(expected.equals(actual))) {
            System.out.printf("%s Expected: %s, Actual: %s\n", description,
                    expected, actual);
            return false;
        } else {
            return true;
        }
    }

    /**
     * Tests expected vs. actual values with intentional failure.
     * 
     * @param actual the calculated boolean value
     * @param description the description of the test
     * @return detailed description of results
     */
    public static boolean forFalse(boolean actual, String description) {
        if (!(actual)) {
            return true;
        } else {
            System.out.printf("%s Expected: false, Actual: true\n",
                    description);
            return false;
        }
    }

    /**
     * Tests expected vs. actual values with no intended failure.
     * 
     * @param actual the final calculated value
     * @param description the description of the test
     * @return detailed description of results
     */
    public static boolean forTrue(boolean actual, String description) {
        if (actual) {
            return true;
        } else {
            System.out.printf("%s Expected: true, Actual: false\n",
                    description);
            return false;
        }
    }

}
