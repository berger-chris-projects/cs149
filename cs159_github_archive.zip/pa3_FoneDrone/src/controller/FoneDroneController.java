package controller;

import simulator.DroneController;
import simulator.Direction;

/**
 * Specifies a drone controller that can find a "fone" in a room using its
 * 10-digit number.
 * 
 * @author Vanessa P
 * @version 11/15/2023
 */

public class FoneDroneController extends DroneController {
    private int[] location;
    private Direction[] options = Direction.values();

    /**
     * Explicit Value Constructor.
     * 
     * @param number the phone's number (###-###-####)
     */
    public FoneDroneController(String number) {
        super(number);
    }

    /**
     * Locates this controller's phone.
     * 
     * @return where the phone was found [x , y]
     */

    @Override
    public int[] getLocationOfPhone() {
        return this.location;
    }

    /**
     * Turns on the drone, and locates the associated "fone".
     */

    @Override
    public void start() {
        this.location = this.searchByMovement(Direction.FORWARD);
    }

    /**
     * Recursively searches all space in a room for the desired "fone".
     * 
     * @param d the direction the drone will search for the "fone"
     * @return the position the phone is found
     */

    public int[] searchByMovement(Direction d) {
        int[] temporary = null;
        temporary = drone.checkForPhone(this.number);
        if (temporary != null) {
            return temporary;
        }
        if (drone.canMove(d) && !drone.hasBeen(d)) {
            drone.move(d);
            temporary = searchByMovement(d);
            drone.move(d.opposite());
        }
        if (temporary == null) {
            for (Direction move : options) {
                if (temporary == null && drone.canMove(move)
                        && !drone.hasBeen(move) && move != d
                        && move != d.opposite()) {
                    temporary = searchByMovement(move);
                }
            }
        }
        return temporary;
    }
}