/**
 * JUnit test class for the abstract utility class FileProcessor;
 * 
 * @author Vanessa P
 * @version 10/30/2023
 */

package testing;

import static org.junit.jupiter.api.Assertions.*;
import java.io.File;
import java.io.IOException;

import io.FileIdentifier;
import membership.Account;
import membership.VIPAccount;
import io.CSVFileProcessor;

import org.junit.jupiter.api.Test;

class FileProcessorTest {

    /**
     * JUnit round trip test case for the superclass and subclass input/output
     * functionality.
     * 
     * @throws IOException 
     */

    @Test
    public void roundTripTest() throws IOException {
        CSVFileProcessor csv1, csv2, csv3;
        Account a1, a2, a3, a4, aN;
        VIPAccount v1, v2, v3, v4, vN, Vn;

        File f = new File("aCcOuNtS.bbb");
        csv1 = new CSVFileProcessor(f);
        FileIdentifier fi = new FileIdentifier("orders", "BRU");
        csv2 = new CSVFileProcessor(fi);
        String s = "dunderhead.com";
        csv3 = new CSVFileProcessor(s);

        a1 = new Account();
        a2 = new Account(1.00, 0.00);
        a3 = new Account();
        a4 = new Account();
        aN = new Account(1001.00, 0.00);

        v1 = new VIPAccount();
        v2 = new VIPAccount(70.00, 3.00, 6);
        v3 = new VIPAccount();
        v4 = new VIPAccount();

        csv1.write(a2);
        // csv1.read(a1); should read to blank account, returns NoSuchElementException
    }
}