package geog.io;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import geog.*;

/**
 * A static class of methods that read data files for BatchGeo.
 * 
 * @author Vanessa P
 * @version 12/2/2023
 */

public class MapReader {

    /**
     * Iterates through a given file for Segments.
     * 
     * @param file the tab seperated value .seg file
     * @return a key, value map of segment ID, segment
     * @throws IOException file input/output failure
     */

    public static Map<String, Segment> readSegments(String file)
            throws IOException {
        Map<String, Segment> m = new HashMap<String, Segment>();
        File capitalF = new File(file);
        Scanner read = new Scanner(capitalF);
        while (read.hasNextLine()) {
            String line = read.nextLine();
            Segment seg = new Segment();
            String id = seg.fromTSV(line);
            if (id != null) {
                m.put(id, seg);
            }
        }
        read.close();
        return m;
    }

    /**
     * Iterates through a given file and map of Segments to their IDs for
     * Streets.
     * 
     * @param file the records of attributes of these Street objects
     * @param segments a key, value map of segment ID, segment
     * @return a key, value map of street ID, street
     * @throws IOException file input/output failure
     */

    public static Map<String, Street> readStreets(String file,
            Map<String, Segment> segments) throws IOException {
        Map<String, Street> m = new HashMap<String, Street>();
        File capitalF = new File(file);
        Scanner read = new Scanner(capitalF);
        while (read.hasNextLine()) {
            String line = read.nextLine();
            String[] info = line.split("\t");
            Street street = new Street(info[0]);
            for (int c = Integer.parseInt(info[1]); c > 0; c--) {
                String key = read.nextLine();
                if (segments.containsKey(key)) {
                    street.add(segments.get(key));
                }
            }
            m.put(info[0], street);
        }
        read.close();
        return m;
    }
}
