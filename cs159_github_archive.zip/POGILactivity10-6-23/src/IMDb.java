import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class IMDb {

    public static void main(String[] args) throws FileNotFoundException {
        File file = new File("title2020.tsv");
        Scanner in = null;
        try { 
            in = new Scanner(file);
        } catch (FileNotFoundException fnfe) {
            
        }
        int count = 0;
        while (count < 1) {
            String tid = in.next();
            String type = in.next();
            String title = in.next();
            File elif = new File("results.tsv");
            PrintWriter pw = new PrintWriter(elif);
            for (int i = 0; i < 5; i++) {
                if (title.charAt(0) == 'A') {
                    pw.write(title);
                }
            }
        System.out.println(tid + " is a " + type + " named " + title);
        count++;
        }
        in.nextLine();
        in.close();
    }

}
