package testing;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import product.Teethbrush;

/**
 * JUnit tests for the Teethbrush superclass.
 * 
 * @author Vanessa P
 * @version 10/16/2023
 */

class TeethbrushTest {

    /**
     * Test case for the getHardness() method.
     */

    @Test
    public void getHardnessTest() {
        Teethbrush tb, tb2, bt, bt2;
        tb = new Teethbrush("716", 3, true);
        tb2 = new Teethbrush("0", 1, false);
        bt = new Teethbrush("5509", 4, true);
        bt2 = new Teethbrush("31210", 5, false);
        int mynum = tb2.getHardness() + 3;

        assertEquals(3, tb.getHardness());
        assertEquals((2 / 2), tb2.getHardness());
        assertEquals((2 * 2), bt.getHardness());
        assertEquals(mynum - 1, tb.getHardness());
        assertEquals(5, bt2.getHardness());
    }

    /**
     * Test case for the getInventory() method.
     */

    @Test
    public void getInventoryTest() {
        Teethbrush tb, tb2, bt, bt2;
        tb = new Teethbrush("716", 3, true);
        tb2 = new Teethbrush("0", 1, false);
        bt = new Teethbrush("5509", 4, true);
        bt2 = new Teethbrush("31210", 5, false);
        int mynum = (tb2.getInventory() - 4);
        int nummy = (bt2.getInventory() * 5);

        assertEquals(tb2.getInventory(), 0);
        assertEquals(tb.getInventory(), nummy);
        assertEquals(bt2.getInventory(), 0);
        assertEquals(bt.getInventory(), tb.getInventory());
        assertEquals((tb.getInventory() - 4), mynum);
    }

    /**
     * Test case for the getModel() method.
     */
    @Test
    public void getModelTest() {
        Teethbrush tb, tb2, bt, bt2;
        tb = new Teethbrush("716", 3, true);
        tb2 = new Teethbrush("0", 1, false);
        bt = new Teethbrush("5509", 4, true);
        bt2 = new Teethbrush("31210", 5, false);

        String myS = "31210";
        String Sym = "716";
        String ySm = "5509";
        String mSy = "0";

        assertEquals(tb.getModel(), Sym);
        assertEquals(tb2.getModel(), mSy);
        assertEquals(bt.getModel(), ySm);
        assertEquals(bt2.getModel(), myS);
    }

    /**
     * Test case for the isPolished() method.
     */
    @Test
    public void isPolishedTest() {
        Teethbrush tb, tb2, bt, bt2;
        tb = new Teethbrush("716", 3, true);
        tb2 = new Teethbrush("0", 1, false);
        bt = new Teethbrush("5509", 4, true);
        bt2 = new Teethbrush("31210", 5, false);

        assertEquals(tb2.isPolished(), false);
        assertEquals(tb.isPolished(), true);
        assertEquals(bt.isPolished(), true);
        assertEquals(bt2.isPolished(), false);
    }

    /**
     * Test case for the setHardness() method.
     */
    @Test
    public void setHardnessTest() {
        Teethbrush tb, tb2, bt, bt2;
        tb = new Teethbrush("716", 3, true);
        tb2 = new Teethbrush("0", 1, false);
        bt = new Teethbrush("5509", 4, true);
        bt2 = new Teethbrush("31210", 5, false);
        tb.setHardness(5);
        tb2.setHardness(-1);
        bt.setHardness(10);
        bt2.setHardness(3);
        assertEquals(tb.getHardness(), 5);
        assertEquals(bt.getHardness(), 5);
        assertEquals(tb2.getHardness(), 0);
        assertEquals(bt2.getHardness(), 3);
    }

    /**
     * Test case for the changeInventory() method.
     */
    @Test
    public void changeInventoryTest() {
        Teethbrush tb, tb2, bt, bt2;
        tb = new Teethbrush("716", 3, true);
        tb2 = new Teethbrush("0", 1, false);
        bt = new Teethbrush("5509", 4, true);
        bt2 = new Teethbrush("31210", 5, false);
        tb.changeInventory(5);
        tb2.changeInventory(-1);
        bt.changeInventory(45);
        bt2.changeInventory(100);
        assertEquals(5, tb.getInventory());
        assertEquals(0, tb2.getInventory());
        assertEquals(45, bt.getInventory());
        assertEquals(100, bt2.getInventory());
        bt.changeInventory(-46);
        assertEquals(45, bt.getInventory());
    }

    /**
     * Test case for the cost() method.
     */
    @Test
    public void costTest() {
        Teethbrush tb, tb2, bt, bt2;
        tb = new Teethbrush("716", 3, true); // $3.05
        tb2 = new Teethbrush("0", 1, false); // $2.10
        bt = new Teethbrush("5509", 4, true); // $3.15
        bt2 = new Teethbrush("31210", 5, false); // $2.50

        assertEquals(tb.cost(), 3.05);
        assertEquals(bt.cost(), 3.15);
        assertEquals(bt2.cost(), 2.50);
        assertEquals(tb2.cost(), 2.10);
        assertEquals(tb.cost(), (bt.cost() - 0.10));
    }

    /**
     * Test case for the shippingCost() method.
     */
    @Test
    public void shippingCostTest() {
        Teethbrush tb, tb2, bt;
        tb = new Teethbrush("716", 3, true);
        tb2 = new Teethbrush("0", 1, false);
        bt = new Teethbrush("5509", 4, true);
        int order1 = 1560;
        boolean seas1 = false; // 134.20
        int order2 = 427;
        boolean seas2 = true; // 153.10
        int order3 = 69;
        boolean seas3 = true; // 45.70

        assertEquals(tb.shippingCost(order1, seas1), 134.20);
        assertEquals(tb2.shippingCost(order2, seas2), 153.10);
        assertEquals(bt.shippingCost(order3, seas3), 45.70);
        tb.changeInventory(order1); // new shipping cost = 134.20
        tb2.changeInventory(order2 - 1); // new shipping cost =
        bt.changeInventory(order3 + 1); // new shipping cost = 47.50
        assertEquals(tb.shippingCost(order1 + 1, seas1), 134.27);
        assertEquals(tb2.shippingCost(order2, seas2), 153.10);
        assertEquals(bt.shippingCost(order3, seas3), 20.70);
    }

}
