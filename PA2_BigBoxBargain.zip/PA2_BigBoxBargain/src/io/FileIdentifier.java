package io;

import java.util.Scanner;

/**
 * An identification data type for files that can be cast as CSV files.
 * 
 * @author Vanessa P
 * @version 10/30/2023
 */

public class FileIdentifier implements CSVRepresentable {
    private String extension;
    private String name;

    /**
     * Explicit Value Constructor.
     * 
     * @param name the file's unique name
     * @param extension the file's type (after the dot)
     */
    public FileIdentifier(String name, String extension) {
        this.name = name;
        this.extension = extension;
    }

    /**
     * Implemented from the CSVRepresentable interface.
     * 
     * @param s the FileIdentifier object's CSV format
     * @return this object's Scanner object for later tokenizing
     */
    public Scanner fromCSV(String s) {
        Scanner read;
        String n, e;

        read = new Scanner(s);
        read.useDelimiter(",");
        n = read.next();
        e = read.next();
        this.name = n;
        this.extension = e;
        return read;
    }

    /**
     * Implemented from the CSVRepresentable interface.
     * 
     * @return this FileIdentifier's fields separated by commas
     */
    public String toCSV() {
        return String.format("%s,%s", name, extension);
    }

    /**
     * Formats this object as a file in a file system.
     * 
     * @return the FileIdentifier represented as a String
     */
    public String toString() {
        return String.format("%s.%s", name, extension);
    }
}
