package testing;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

/**
 * JUnit tests for the Electric Teethbrush subclass.
 * 
 * @author Vanessa P
 * @version 10/16/2023
 */

class ElectricTeethbrushTest {

    @Test
    public static void costTest() {
        ElectricTeethbrush etb, etb2, bte, bte2;
        etb = new ElectricTeethbrush("E716", 3, true, false, false);
        etb2 = new ElectricTeethbrush("E0RU", 1, false, true, true);
        bte = new ElectricTeethbrush("E5509U", 4, true, false, true);
        bte2 = new ElectricTeethbrush("E31210R", 5, false, true, false);
    }
    
    @Test
    public static void isRechargeableTest() {
        ElectricTeethbrush etb, etb2, bte, bte2;
        etb = new ElectricTeethbrush("E716", 3, true, false, false);
        etb2 = new ElectricTeethbrush("E0RU", 1, false, true, true);
        bte = new ElectricTeethbrush("E5509U", 4, true, false, true);
        bte2 = new ElectricTeethbrush("E31210R", 5, false, true, false);
    }
    
    @Test
    public static void isUltrasonicTest() {
        ElectricTeethbrush etb, etb2, bte, bte2;
        etb = new ElectricTeethbrush("E716", 3, true, false, false);
        etb2 = new ElectricTeethbrush("E0RU", 1, false, true, true);
        bte = new ElectricTeethbrush("E5509U", 4, true, false, true);
        bte2 = new ElectricTeethbrush("E31210R", 5, false, true, false);
    }

}
