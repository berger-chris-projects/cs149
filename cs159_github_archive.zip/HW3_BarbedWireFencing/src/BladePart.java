/**
 * The fixed enumeration of the two parts of a fencing blade.
 * 
 * @author Chris Berger
 * @version 9/22/2023
 */
public enum BladePart {
    EDGE, TIP
}
