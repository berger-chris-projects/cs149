// We give them this class

/**
 * A simple unit testing harness that uses overloaded methods.
 *
 * @author  Prof. David Bernstein, James Madison University
 * @version 2.0
 */
public class Test {

	private static int failed = 0;
	private static int passed = 0;

	/**
     * Display an alert if the actual double value and the expected double
     * value differ by more than the given tolerance.
     *
     * @param expected     The expected value
     * @param actual       The actual value
     * @param tolerance    The tolerance
     * @param description  A description of the test
     * @return true if the two are equal; false otherwise
     */
    public static boolean forEqual(double expected, double actual, double tolerance, 
    		String description) {
    	
        double difference;
        
        difference = Math.abs(expected - actual);
        if (difference > tolerance) {
            System.out.printf("%s Expected: %f, Actual: %f\n", 
                              description, expected, actual);
            failed++;
            return false;
        } else {
        	passed++;
        	return true;
        }
    }
    
    /**
     * Display an alert if the actual int value is not equal to the
     * expected value.
     *
     * @param expected     The expected value
     * @param actual       The actual value
     * @param description  A description of the test
     * @return true if the two are equal; false otherwise
     */
    public static boolean forEqual(int expected, int actual, String description) {
        if (expected != actual) {
            System.out.printf("%s Expected: %d, Actual: %d\n", 
                              description, expected, actual);
            failed++;
            return false;
        } else {
        	passed++;
        	return true;
        }
    }
    
    /**
     * Display an alert if the contents of the actual String object
     * is not not equal to the contents of the expected value String object.
     *
     * @param expected     The expected value
     * @param actual       The actual value
     * @param description  A description of the test
     * @return true if the two are equal; false otherwise
     */
    public static boolean forEqual(String expected, String actual, 
    		String description) {
    	
        if (!expected.equals(actual)) {
            System.out.printf("%s Expected: %s, Actual: %s\n", 
                              description, expected, actual);
            failed++;
            return false;
        } else {
        	passed++;
        	return true;
        }
    }
    
    /**
     * Display an alert if the actual boolean is not false.
     *
     * @param actual       The actual value
     * @param description  A description of the test
     * @return true if actual is false
     */
    public static boolean forFalse(boolean actual, String description) {
        if (actual) {
            System.out.printf("%s Expected: false, Actual: true\n", 
                              description);
            failed++;
            return false;
        } else {
        	passed++;
        	return true;
        }
    }
    
    /**
     * Display an alert if the actual boolean is not true.
     *
     * @param actual       The actual value
     * @param description  A description of the test
     * @return true if actual is true
     */
    public static boolean forTrue(boolean actual, String description) {
        if (!actual) {
            System.out.printf("%s Expected: true, Actual: false\n", 
                              description);
            failed++;
            return false;
        } else {
        	passed++;
        	return true;
        }
    }
    
    /**
     * Get the summary statistics.
     * 
     * @return The summary statistics
     */
    public static String getSummary() {
    	return String.format("Failed %d of %d total tests", failed, failed+passed);
    }
}