package geog;

import java.util.ArrayList;
import java.util.List;

/**
 * A data type which outlines a street of houses in BatchGeo.
 * 
 * @author Vanessa P
 * @version 12/2/2023
 */

public class Street {
    private String name;
    private List<Segment> segments;

    /**
     * Explicit Value Constructor.
     * 
     * @param name this street's name
     */

    public Street(String name) {
        this.name = name;
        this.segments = new ArrayList<Segment>();
    }

    /**
     * Adds a given segment to this street.
     * 
     * @param segment the Segment on this street
     */

    public void add(Segment segment) {
        segments.add(segment);
    }

    /**
     * Scans the street for the given house number.
     * 
     * @param number the house to look for
     * @return a list of OnSegmentLocation objects for found houses
     */

    public List<OnSegmentLocation> geocode(int number) {
        List<OnSegmentLocation> listOSL = new ArrayList<OnSegmentLocation>(0);
        for (Segment seg : segments) {
            if (seg.contains(number)) {
                OnSegmentLocation terped = seg.interpolate(number);
                if (terped != null) {
                    listOSL.add(terped);
                }
            }
        }
        return listOSL;
    }

    /**
     * Provides this street's name.
     * 
     * @return the identifiable String of this object
     */

    public String getName() {
        return name;
    }
}
