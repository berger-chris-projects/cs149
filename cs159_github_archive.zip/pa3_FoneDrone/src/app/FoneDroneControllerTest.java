package app;

import java.lang.reflect.InvocationTargetException;
import javax.swing.SwingUtilities;

import controller.*;
import simulator.*;

/**
 * A driver for running FoneDroneController.
 */
public class FoneDroneControllerTest {

    /**
     * The entry-point of the application.
     * 
     * @param args The command line arguments (which are ignored)
     * @throws InterruptedException If something goes wrong with the GUI
     * @throws InvocationTargetException If something goes wrong with the GUI
     */
    public static void main(String[] args) throws InterruptedException, 
        InvocationTargetException {
        
        Drone drone;
        FoneDroneController controller;

        controller = new FoneDroneController("540-568-1671");
        drone = new Drone(controller, "halls.txt");
        controller.setDrone(drone);
        SwingUtilities.invokeAndWait(drone);
    }

}
