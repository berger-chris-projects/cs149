/**
 * An order of items for a CS party.
 * 
 * @author Vanessa
 * @version 10/2/2023
 */
public class Order {
    private int number;
    private Item item;

    /**
     * Explicit Value Constructor.
     * 
     * @param number whole number of items being ordered
     * @param item the associated Item object
     */
    public Order(int number, Item item) {
        this.number = number;
        Item i = new Item(item);
        this.item = i;
    }

    /**
     * Duplicate Value Constructor.
     * 
     * @param other the other Order object being duplicated
     */
    public Order(Order other) {
        double p = other.getPrice() / other.getNumber();
        int s = other.getServes() / other.getNumber();
        Item i = new Item(other.getDescription(), s, p);
        this.number = other.getNumber();
        this.item = i;
    }

    /**
     * Describes the items being ordered.
     * 
     * @return the description of the items being ordered
     */
    public String getDescription() {
        return this.item.getDescription();
    }

    /**
     * Provides the number of items in this order.
     * 
     * @return the number of items being ordered
     */
    public int getNumber() {
        return this.number;
    }

    /**
     * The cost of a number of items at its price.
     * 
     * @return the dollars and cents an order costs
     */
    public double getPrice() {
        return this.item.getPrice() * this.number;
    }

    /**
     * The number of servings of a number of items in an order.
     * 
     * @return the number of servings of this order's item
     */
    public int getServes() {
        return this.item.getServes() * this.number;
    }

    /**
     * Changes an order's number of items.
     * 
     * @param number it's new number of items
     */
    public void setNumber(int number) {
        this.number = number;
    }

    /**
     * Formats the order into a readable String.
     * 
     * @return the order's formatted string
     */
    public String toString() {
        return String.format("%d orders of %s", this.number,
                this.item.toString());
    }

}
