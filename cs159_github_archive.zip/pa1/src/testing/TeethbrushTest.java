package testing;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import brushes.Teethbrush;

/**
 * JUnit tests for the Teethbrush superclass.
 * 
 * @author Vanessa P
 * @version 10/16/2023
 */

class TeethbrushTest {

    /**
     * Test case for the getHardness() method.
     */
    @Test
    public static void getHardnessTest() {
        Teethbrush tb, tb2, bt, bt2;
        tb = new Teethbrush("716", 3, true);
        tb2 = new Teethbrush("0", 1, false);
        bt =  new Teethbrush("5509", 4, true);
        bt2 = new Teethbrush("31210", 5, false);
        int mynum = tb2.getHardness() + 3;
        
        assertEquals(tb.getHardness(), 3);
        assertEquals(tb2.getHardness(), (2/2));
        assertEquals(bt.getHardness(), (2*2));
        assertTrue((bt.getHardness() / 2), (tb2.getHardness() * 2));
        assertFalse(bt2.getHardness() == tb2.getHardness());
        assertTrue(tb.getHardness() == mynum);
        assertFalse(bt2.getHardness() == 4);
    }

    /**
     * Test case for the getInventory() method.
     */
    @Test
    public static void getInventoryTest() {
        Teethbrush tb, tb2, bt, bt2;
        tb = new Teethbrush("716", 3, true);
        tb2 = new Teethbrush("0", 1, false);
        bt =  new Teethbrush("5509", 4, true);
        bt2 = new Teethbrush("31210", 5, false);
        int mynum = (tb2.getInventory() - 4);
        int nummy = (bt2.getInventory() * 5);
        
        assertEquals(tb2.getInventory(), 0);
        assertEquals(tb.getInventory(), nummy);
        assertTrue(tb.getInventory() < 1);
        assertFalse(bt.getInventory(), -15);
        assertTrue(tb2.getInventory() == 0);
        assertFalse((bt2.getInventory() - 9), mynum);
    }

    /**
     * Test case for the getModel() method.
     */
    @Test
    public static void getModelTest() {
        Teethbrush tb, tb2, bt, bt2;
        tb = new Teethbrush("716", 3, true);
        tb2 = new Teethbrush("0", 1, false);
        bt =  new Teethbrush("5509", 4, true);
        bt2 = new Teethbrush("31210", 5, false);
        String myS = "31210";
        String Sym = "550";
        String ySm = "11011011";
        assert
    }

    /**
     * Test case for the isPolished() method.
     */
    @Test
    public static void isPolishedTest() {
        Teethbrush tb, tb2, bt, bt2;
        tb = new Teethbrush("716", 3, true);
        tb2 = new Teethbrush("0", 1, false);
        bt =  new Teethbrush("5509", 4, true);
        bt2 = new Teethbrush("31210", 5, false);
        
    }

    /**
     * Test case for the setHardness() method.
     */
    @Test
    public static void setHardnessTest() {
        Teethbrush tb, tb2, bt, bt2;
        tb = new Teethbrush("716", 3, true);
        tb2 = new Teethbrush("0", 1, false);
        bt =  new Teethbrush("5509", 4, true);
        bt2 = new Teethbrush("31210", 5, false);
        
    }

    /**
     * Test case for the changeInventory() method.
     */
    @Test
    public static void changeInventoryTest() {
        Teethbrush tb, tb2, bt, bt2;
        tb = new Teethbrush("716", 3, true);
        tb2 = new Teethbrush("0", 1, false);
        bt =  new Teethbrush("5509", 4, true);
        bt2 = new Teethbrush("31210", 5, false);
        
        assertTrue(tb.changeInventory(5));
        assertFalse(tb2.changeInventory(-1));
        assertTrue(tb2.changeInventory(69));
        assertFalse(bt.changeInventory(0));
        assertTrue(bt2.changeInventory(1));
        assertFalse(bt.changeInventory(-0));
    }

    /**
     * Test case for the cost() method.
     */
    @Test
    public static void costTest() {
        Teethbrush tb, tb2, bt, bt2;
        tb = new Teethbrush("716", 3, true); // $3.05
        tb2 = new Teethbrush("0", 1, false); // $2.10
        bt =  new Teethbrush("5509", 4, true); // $3.15
        bt2 = new Teethbrush("31210", 5, false); // $2.50
        
        
    }

    /**
     * Test case for the shippingCost() method.
     */
    @Test
    public static void shippingCostTest() {
        Teethbrush tb, tb2, bt, bt2;
        tb = new Teethbrush("716", 3, true);
        tb2 = new Teethbrush("0", 1, false);
        bt =  new Teethbrush("5509", 4, true);
        bt2 = new Teethbrush("31210", 5, false);
        
    }

    
}
