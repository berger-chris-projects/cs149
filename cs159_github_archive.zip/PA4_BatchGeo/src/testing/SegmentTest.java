package testing;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import geog.*;

class SegmentTest {

	private static double TOL = 0.01;
	
	@Test
	void contains() {
		Segment s = new Segment();
		
		s.fromTSV("78907109	-78.936727	+37.876257	-78.935106	+37.874816	0.4257770	A41	1	246");
		assertTrue(s.contains(1));
		assertTrue(s.contains(123));
		assertTrue(s.contains(246));
		assertFalse(s.contains(1000));
	}

	@Test
	void interpolate() {
		Segment s = new Segment();
		
		s.fromTSV("75739596	-78.737162	+38.380782	-78.736349	+38.381549	0.1187020	A41	1900	1999");
		OnSegmentLocation loc = s.interpolate(1930);
		assertEquals(-78.736916, loc.getLongitude(), TOL);
		assertEquals(38.381014, loc.getLatitude(), TOL);
		
		
		assertNull(s.interpolate(350));
	}
}
