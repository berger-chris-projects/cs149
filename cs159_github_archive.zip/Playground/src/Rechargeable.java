public interface Rechargeable {
    int MAX_CHARGE = 10;

    int getCharge();

    void recharge();
}
