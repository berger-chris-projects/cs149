/**
 * A fencing bout with two fencers, left and right.
 * 
 * @author Chris Berger
 * @version 9/22/2023
 */
public class Bout {

    private FencingEvent event;
    private int scoreLeft;
    private int scoreRight;
    private String fencerLeft;
    private String fencerRight;

    /**
     * Explicit Value Constructor.
     * 
     * @param event the event in which the bout takes place
     * @param fencerLeft one of two R/L fencers in a match
     * @param fencerRight one of two R/L fencers in a match
     */

    public Bout(FencingEvent event, String fencerLeft, String fencerRight) {
        this.event = event;
        this.fencerLeft = fencerLeft;
        this.fencerRight = fencerRight;
    }

    /**
     * Provides the FencingEvent object of this bout.
     * 
     * @return FencingEvent the event this bout is in
     */

    public FencingEvent getEvent() {
        return event;
    }

    /**
     * Provides the string of the left fencer.
     * 
     * @return the left fencer's name
     */

    public String getLeftFencer() {
        return fencerLeft;
    }

    /**
     * Provides the string of the right fencer.
     * 
     * @return String the right fencer's 'name'
     */

    public String getRightFencer() {
        return fencerRight;
    }

    /**
     * Increases the score of the left fencer.
     */

    public void increaseLeftScore() {
        scoreLeft += 1;
    }

    /**
     * Increases the score of the right fencer.
     */

    public void increaseRightScore() {
        scoreRight += 1;
    }

    /**
     * Converts attributes of this class into a readable format.
     * 
     * @return String the final string, formatted as specified
     */

    public String toString() {
        String s = String.format("%s %d, %s %d", fencerLeft, scoreLeft,
                fencerRight, scoreRight);
        return s;
    }
}