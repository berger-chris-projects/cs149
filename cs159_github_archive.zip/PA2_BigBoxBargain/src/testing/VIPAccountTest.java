/**
 * JUnit test class for the (CSVRepresentable) subclass VIPAccount
 * 
 * @author Vanessa P
 * @version 10/30/2023
 */

package testing;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import membership.VIPAccount;

class VIPAccountTest {

    /**
     * JUnit test case for the subclass constructors and get attribute methods.
     */

    @Test
    public void constructorsandGettersTest() {
        VIPAccount v1, v2, v3, v4;
        v1 = new VIPAccount();
        v2 = new VIPAccount(36.79, 49.99, 11); // rp = 0.021
        v3 = new VIPAccount(55.00, 0.55, 90); // rp = 0.11
        v4 = new VIPAccount(99.99, 0.01, 274); // rp = [0.274] 0.15

        assertEquals(0.00, v1.getPurchases());
        assertEquals(274, v4.getVisits());
        assertEquals(0.01, v1.getRewardPercentage());
        assertEquals(0.02, v2.getRewardPercentage());
        assertEquals(0.09999999999999999, v3.getRewardPercentage());
        assertEquals(0.15, v4.getRewardPercentage());
    }

    /**
     * JUnit test case for the overriden toCSV() method.
     */

    @Test
    public void overrideToCSVTest() {
        VIPAccount v1, v2, v3, v4;
        v1 = new VIPAccount();
        v2 = new VIPAccount(36.79, 49.99, 11); // rp = 0.021
        v3 = new VIPAccount(55.00, 0.55, 90); // rp = 0.11
        v4 = new VIPAccount(99.99, 0.01, 274); // rp = [0.274] 0.15
        String s1 = "0.00,0.00,0", s2 = "36.79,49.99,11", s3 = "55.00,0.55,90",
                s4 = "99.99,0.01,274";
        assertEquals(s1, v1.toCSV());
        assertEquals(s2, v2.toCSV());
        assertEquals(s3, v3.toCSV());
        assertEquals(s4, v4.toCSV());
    }

    /**
     * JUnit test case for the overriden fromCSV() and the overriden protected
     * increasePurchase() methods.
     */

    @Test
    public void overrideFromCSVTest() {
        VIPAccount v1, v2, v3, v4;
        v1 = new VIPAccount();
        v2 = new VIPAccount();
        v3 = new VIPAccount();
        v4 = new VIPAccount();
        String s1 = "0.00,0.00,0", s2 = "36.79,49.99,11", s3 = "55.00,0.55,90",
                s4 = "99.99,0.01,274";
        
        v1.fromCSV(s1);
        v2.fromCSV(s2);
        v3.fromCSV(s3);
        v4.fromCSV(s4);
        
        assertEquals(0.00, v1.availableCredit());
        assertEquals(49.99, v2.getCreditsUsed());
        assertEquals(55.00, v3.getPurchases());
        assertEquals(274, v4.getVisits());
    }

    /**
     * JUnit test case for the overriden canUseExpressLine() method.
     */

    @Test
    public void overrideCanUseExpressLineTest() {
        VIPAccount v1, v2, v3, v4;
        v1 = new VIPAccount();
        v2 = new VIPAccount(3679.50, 49.99, 9); 
        v3 = new VIPAccount(600.00, 0.55, 0);
        v4 = new VIPAccount(99.99, 0.01, 274);
        assertEquals(false, v1.canUseExpressLine());
        assertEquals(true, v2.canUseExpressLine());
        assertEquals(false, v3.canUseExpressLine());
        assertEquals(true, v4.canUseExpressLine());
        
    }

    /**
     * JUnit test case for the overriden toString() method.
     */

    @Test
    public void overrideToStringTest() {
        VIPAccount v1, v2, v3, v4;
        v1 = new VIPAccount();
        v2 = new VIPAccount(36.79, 49.99, 11); // AC 0.3679 - = 0
        v3 = new VIPAccount(600.00, 0.55, 90); // AC 600 * 0.1 - 0.55 = 59.45
        v4 = new VIPAccount(99.99, 0.01, 274); // AC 0.9999 - 0.01 = 0.99
        String s1 = "Purchases: 0.00\nCredits Used: 0.00\nCredits available: 0.00\nVisits: 0";
        String s2 = "Purchases: 36.79\nCredits Used: 49.99\nCredits available: 0.00\nVisits: 11";
        String s3 = "Purchases: 600.00\nCredits Used: 0.55\nCredits available: 59.45\nVisits: 90";
        String s4 = "Purchases: 99.99\nCredits Used: 0.01\nCredits available: 14.99\nVisits: 274";
        assertEquals(s1, v1.toString());
        assertEquals(s2, v2.toString());
        assertEquals(s3, v3.toString());
        assertEquals(s4, v4.toString());
    }
}
