import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Test {
   
    public static void main(String[] args) throws FileNotFoundException {
        File file = new File("notes159.txt");
        Scanner read = new Scanner(file);
        
        while (read.hasNextLine()) {
            String line =  read.nextLine();
            System.out.println(line);
        }
        read.close();
        
        
        
        
        
    }
}
