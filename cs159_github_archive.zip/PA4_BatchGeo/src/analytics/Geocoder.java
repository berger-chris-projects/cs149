package analytics;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import geog.*;
import geog.io.*;

/**
 * A data type that maps Streets to coordinate locations.
 * 
 * @author Vanessa P
 * @version 12/1/23
 */

public class Geocoder {
    private Map<String, Street> streets;

    /**
     * Explicit Value Constructor.
     * 
     * @param file the file to derive this object from
     * @throws IOException input/output failure
     */

    public Geocoder(String file) throws IOException {
        Map<String, Segment> segments = MapReader.readSegments(file + ".seg");
        this.streets = MapReader.readStreets(file + ".str", segments);
    }

    /**
     * Geolocates an address's longitude and latitude.
     * 
     * @param name the street name
     * @param number the house's numeric address
     * @return the coordinates of this address
     */

    public List<OnSegmentLocation> fromAddress(String name, int number) {
        List<OnSegmentLocation> alOSL = new ArrayList<OnSegmentLocation>(0);
        for (Street s : streets.values()) {
            if (name == s.getName()) {
                List<OnSegmentLocation> listOSL = s.geocode(number);
                Collections.sort(listOSL);
                alOSL.addAll(listOSL);
            }
        }
        return alOSL;
    }
}
