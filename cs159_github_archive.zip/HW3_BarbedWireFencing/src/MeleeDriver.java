
/**
 * There are three fencers in a melee. Each fencer fights every other fencer, so there
 * are three bouts in total. What makes it interesting is that the phrases in the bouts
 * are interleaved by round.
 * * 
 * In each round, each fencer fights one phrase with another fencer using a particular weapon 
 * (that is chosen at the start of the melee). When that phrase concludes, one of the two fencers moves on to the next bout.
 */
public class MeleeDriver {

	public static void main(String[] args) {
		
		Bout bernsteinVstewart, bernsteinVduan, duanVstewart;
		
		bernsteinVstewart = new Bout(FencingEvent.EPEE, "Bernstein", "Stewart");
		bernsteinVduan = new Bout(FencingEvent.SABRE, "Bernstein", "Duan");
		duanVstewart = new Bout(FencingEvent.FOIL, "Duan", "Stewart");
		
		// Round 1
		processPhrase(bernsteinVstewart, "Bernstein", BladePart.TIP, BodyPart.LEGS);
		processPhrase(bernsteinVduan, "Duan", BladePart.EDGE, BodyPart.HEAD);
		processPhrase(duanVstewart, "Duan", BladePart.TIP, BodyPart.ARMS);
		
		// Round 2
		processPhrase(bernsteinVstewart, "Stewart", BladePart.TIP, BodyPart.HEAD);
		processPhrase(bernsteinVduan, "Duan", BladePart.EDGE, BodyPart.HEAD);
		processPhrase(duanVstewart, "Stewart", BladePart.TIP, BodyPart.ARMS);
		
		// Round 3
		processPhrase(bernsteinVstewart, "Bernstein", BladePart.EDGE, BodyPart.ARMS);
		processPhrase(bernsteinVduan, "Duan", BladePart.EDGE, BodyPart.LEGS);
		processPhrase(duanVstewart, "Stewart", BladePart.TIP, BodyPart.HANDS);
		

		// Round 4
		processPhrase(bernsteinVstewart, "Stewart", BladePart.TIP, BodyPart.TORSO);
		processPhrase(bernsteinVduan, "Duan", BladePart.EDGE, BodyPart.ARMS);
		processPhrase(duanVstewart, "Duan", BladePart.TIP, BodyPart.TORSO);

		// Print the scores after four rounds of the three bouts
		System.out.println(bernsteinVstewart.toString());
		System.out.println(bernsteinVduan.toString());
		System.out.println(duanVstewart.toString());
	}
	
	/**
	 * Process a phrase in a bout to determine if a point was scored.
	 * 
	 * @param bout The bout
	 * @param offensiveFencer The fencer that was on offense
	 * @param bladePart The part of the blade that contacted the defensive fencer
	 * @param bodyPart The part of the body on the defensive fencer that was contacted
	 */
	private static void processPhrase(Bout bout, String offensiveFencer, BladePart bladePart, BodyPart bodyPart) {
		FencingEvent event = bout.getEvent();
		if (event.isScoringTouch(bladePart, bodyPart)) {
			if (offensiveFencer.equals(bout.getLeftFencer())) bout.increaseLeftScore();
			else bout.increaseRightScore();
		}
	}
}
