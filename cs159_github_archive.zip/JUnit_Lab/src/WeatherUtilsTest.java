import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

/**
 * Tests the WeatherUtils Class.
 * 
 * @author Vanessa Pierce
 * @version 9/25/2023
 */
class WeatherUtilsTest {

    /**
     * Tests the constructor (for 100% coverage).
     */
    @Test

    public void testDefaultConstructor() {
        new WeatherUtils();
    }

    /**
     * Tests the weatherAdvice method.
     */
    @Test

    void testWeatherAdvice() {
        assertEquals("CANCEL", WeatherUtils.weatherAdvice(71.1, 6.2));
        assertEquals("WARN", WeatherUtils.weatherAdvice(43.3, 4.5));
        assertEquals("WARN", WeatherUtils.weatherAdvice(45.1, 2.9));
        assertEquals("ALL CLEAR", WeatherUtils.weatherAdvice(27.8, 0.1));
        assertEquals("ALL CLEAR", WeatherUtils.weatherAdvice(44.9, 3.9));
        assertEquals("CANCEL", WeatherUtils.weatherAdvice(99.0, 1.6));
        assertEquals("CANCEL", WeatherUtils.weatherAdvice(70.0, 6.4));
        assertEquals("CANCEL", WeatherUtils.weatherAdvice(47.8, 4.7));
        assertEquals("ALL CLEAR", WeatherUtils.weatherAdvice(0.1, 0.1));
    }

    /**
     * Test that the constructor validates properly. NOTE: the Atom class is
     * just an example, the idea here is that the Atom class's constructor
     * should throw an IllegalArgumentException if the atomic number or atomic
     * weight are invalid (e.g. negative).
     */
    @Test

    public void constructorIllegalArguments() {
        try {
            WeatherUtils.weatherAdvice(-0.5, 0.9);

            fail("Constructor should have thrown an IllegalArgumentException");
        } catch (IllegalArgumentException iae) {
            System.out.println("you did it wrong");
        }
        try {
            WeatherUtils.weatherAdvice(1.3, -99.0);

            fail("Constructor should have thrown an IllegalArgumentException");
        } catch (IllegalArgumentException iae) {
            System.out.println("you did it wrong");
        }
    }

}
