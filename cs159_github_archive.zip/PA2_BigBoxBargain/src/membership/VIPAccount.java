package membership;

import java.util.Scanner;

/**
 * Outlines the (CSVRepresentable) subclass at Big Box Bargains.
 * 
 * @author Vanessa P
 * @version 10/30/2023
 */


public class VIPAccount extends Account {
    private int visits;

    /**
     * New VIP Account Value Constructor at BBB.
     */

    public VIPAccount() {
        super();
    }

    /**
     * Explicit Value Constructor.
     * 
     * @param purchases this customer's total spent to-date at BBB
     * @param creditsUsed this customer's total used store credit
     * @param visits this customer's total visits to-date at BBB
     */

    public VIPAccount(double purchases, double creditsUsed, int visits) {
        super(purchases, creditsUsed);
        this.visits = visits;
    }

    /**
     * Derives this VIP account owner's properties from a CSV file.
     * 
     * @param s the comma-separated values of this object
     * @return the unclosed Scanner object for future tokenizing
     */

    @Override
    public Scanner fromCSV(String s) {
        Scanner read;
        double p, c;
        int v;

        read = new Scanner(s);
        read.useDelimiter(",");
        p = read.nextDouble();
        c = read.nextDouble();
        v = read.nextInt();
        this.increasePurchases(p);
        this.increaseCreditsUsed(c);
        this.visits = v;
        return read;
    }

    /**
     * Formats this VIP account owner's properties as comma-separated values.
     * 
     * @return the comma-separated properties of this VIP account
     */

    @Override
    public String toCSV() {
        return String.format("%s,%d", super.toCSV(), this.getVisits());
    }

    /**
     * Decides whether a VIP account owner can use the express check out line.
     * 
     * @return whether this VIP account owner can use the faster line
     */

    @Override
    public boolean canUseExpressLine() {
        boolean b = true;
        if (this.visits < 10) {
            b = super.canUseExpressLine();
        }
        return b;
    }

    /**
     * Determines this VIP account owner's reward credit percentage.
     * 
     * @return this VIP account owner's store credit reward rebate
     */

    @Override
    public double getRewardPercentage() {
        double viprp = (this.visits / 10) * 0.01;
        if (viprp + super.getRewardPercentage() > 0.15) {
            return 0.15;
        }
        return (viprp + super.getRewardPercentage());
    }

    /**
     * Returns the amount of times this account owner has checked out at BBB.
     * 
     * @return the number of separate times this customer has spent money
     */

    public int getVisits() {
        return this.visits;
    }

    /**
     * Updates this VIP account owner's purchases and visits.
     * 
     * @param amount the amount of money spent on this purchase
     */
    @Override
    protected void increasePurchases(double amount) {
        super.increasePurchases(amount);
        this.visits++;
    }

    /**
     * Formats this VIP account owner's properties as a helpful String.
     * 
     * @return this customers purchases, used credits, and number of visits
     */
    public String toString() {
        return String.format("%s\nVisits: %d", super.toString(),
                this.getVisits());
    }
}
