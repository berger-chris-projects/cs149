
/**
 * Verifies specific inputs into PhraseCypher's class methods.
 * 
 * @author  Chris Berger
 * @version 9/25/2023
 */
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class HeuristicTests {

    /**
     * Tests the charOf method.
     */
    @Test

    public void charOfTest1() {
        char c = (char) 0;
        assertEquals('Z', PhraseCypher.charOf(26));
        assertEquals('M', PhraseCypher.charOf(13));
        assertEquals((char) ' ', PhraseCypher.charOf(0));
        assertEquals(c, PhraseCypher.charOf((54 / 2)));
        assertEquals(c, PhraseCypher.charOf(-15));
        assertEquals(c, PhraseCypher.charOf(999));
    }

    /**
     * Tests the valueOf method.
     */
    @Test

    public void valueOfTest1() {
        assertEquals(15, PhraseCypher.valueOf('O'));
        assertEquals(0, PhraseCypher.valueOf((char) ' '));
        assertEquals(-1, PhraseCypher.valueOf('('));
        assertEquals(-1, PhraseCypher.valueOf('9'));
        assertEquals(-1, PhraseCypher.valueOf('='));
        assertEquals(26, PhraseCypher.valueOf('Z'));
    }

    /**
     * Tests the decrypt method.
     */
    @Test
    // 1 2 3 4
    public void decryptTest1() {
        PhraseCypher cypher = new PhraseCypher(
                "THE QUICK BROWN FOX JUMPS OVER THE LAZY DOGGY");
        int[] a = new int[] { 36 };
        assertEquals("A", cypher.decrypt(a));
        assertEquals((String) "", cypher.decrypt(null));

        int[] b = new int[] { 0, 44, 5, 23, 19, 0 };
        assertEquals("TYUP T", cypher.decrypt(b));
        assertEquals("YUP", cypher.decrypt(new int[] { 44, 5, 23 }));

        // exceptions
        int[] c = new int[0];
        assertEquals((String) "", cypher.decrypt(c));
        assertEquals((String) "", cypher.decrypt(new int[0]));

    }

    /**
     * Tests the encrypt method.
     */
    @Test

    public void encryptTest1() { // 012345678901234567890123456
        PhraseCypher cypher = new PhraseCypher(" ABCDEFGHIJKLMNOPQRSTUVWXYZ");
        int[] actual = cypher.encrypt((String) "");
        int[] expected = new int[0];
        assertArrayEquals(expected, actual);
        actual = cypher.encrypt(null);
        expected = new int[0];
        assertArrayEquals(expected, actual);
        actual = cypher.encrypt("SILLY!?/");
        expected = new int[] { 19, 9, 12, 12, 25, -1, -1, -1 };
        assertArrayEquals(expected, actual);
        actual = cypher.encrypt("NOPE");
        expected = new int[] { 14, 15, 16, 5 };
        assertArrayEquals(expected, actual);

        PhraseCypher saifhr = new PhraseCypher(
                " DOPE BLARG CDFHIJKMNQSTUVW X Y Z");
        actual = saifhr.encrypt("JMU DUKES");
        expected = new int[] { 17, 19, 24, 0, 1, 24, 18, 4, 22 };
        assertArrayEquals(expected, actual);
        actual = saifhr.encrypt("     BLA  ");
        expected = new int[] { 0, 0, 0, 0, 0, 6, 7, 8, 0, 0 };
        assertArrayEquals(expected, actual);
        actual = saifhr.encrypt(String.format("DP CDF"));
        expected = new int[] { 1, 3, 0, 12, 1, 14 };
        assertArrayEquals(expected, actual);
    }

    /**
     * Tests illegal arguments for the constructor.
     */
    @Test

    public void constructorExceptionTest() {
        try {
            PhraseCypher c = new PhraseCypher(null);
            fail("An IllegalArgumentException should have been thrown (but wasn't).");
        } catch (IllegalArgumentException iae) {
            System.out.println(iae);
        }
        try {
            PhraseCypher cypher = new PhraseCypher(
                    "UNSATISFYING".toLowerCase());
            fail("An IllegalArgumentException should have been thrown (but wasn't).");
        } catch (IllegalArgumentException ex) {
            System.out.println(ex);
        }
        try {
            PhraseCypher tsee = new PhraseCypher("-1");
            fail("An IllegalArgumentException should have been thrown (but wasn't).");
        } catch (IllegalArgumentException eai) {
            System.out.println(eai);
        }

        try {
            PhraseCypher see = new PhraseCypher((String) "");
            fail("An IllegalArgumentException should have been thrown (but wasn't).");
        } catch (IllegalArgumentException e) {
            System.out.println(e);

        }
        try {
            PhraseCypher si = new PhraseCypher(" ? // 5689");
            fail("An IllegalArgumentException should have been thrown (but wasn't).");
        } catch (IllegalArgumentException illargexc) {
            System.out.println(illargexc);
        }
    }
}