package brushes;
/**
 * Specifies the Teethbrush data type.
 * 
 * @author Vanessa P
 * @version 10/13/23
 */

public class Teethbrush {
    private static final double BASE_HEAD_COST = 2.00;
    private static final double HARDNESS_UPCHARGE = 0.10;
    private static final double LARGE_ORDER_DISCOUNT = 0.30;
    private static final double POLISHED_UPCHARGE = 0.75;
    private static final double STOCKING_COST = 25.00;
    private static final double UNIT_SHIPPING_COST_OVERSEAS = 0.30;
    private static final double UNIT_SHIPPING_COST_LOCAL = 0.10;
    private static final int LARGE_ORDER = 1000;

    private boolean polished;
    private int hardness;
    private int inventory;
    private String model;

    /**
     * Explicit Value Constructor.
     * 
     * @param model the manufacturer's model name
     * @param hardness relative bristle stiffness (0-5)
     * @param polished if the bristles are rounded or flat
     */

    public Teethbrush(String model, int hardness, boolean polished) {
        this.model = model;
        this.hardness = hardness;
        this.polished = polished;
    }

    /**
     * Updates the amount of brushes in stock.
     * 
     * @param amount number of items ordered
     * @return the order can be filled w/o needing to stock
     */

    public boolean changeInventory(int amount) {
        if (this.inventory - amount < 0) {
            return false;
        }
        this.inventory += amount;
        return true;
    }

    /**
     * The dollar amount of a specific brush.
     * 
     * @return the total price of this item
     */

    public double cost() {
        double c = (this.getHardness() * HARDNESS_UPCHARGE) + BASE_HEAD_COST;
        if (this.isPolished()) {
            return c + POLISHED_UPCHARGE;
        }
        return c;
    }

    /**
     * Provides this brush's bristle hardness value.
     * 
     * @return the relative bristle stiffness (0-5)
     */

    public int getHardness() {
        return this.hardness;
    }

    /**
     * Returns the current inventory amount.
     * 
     * @return the number of items available to sell
     */

    public int getInventory() {
        return this.inventory;
    }

    /**
     * States the make and model of this brush.
     * 
     * @return the accompanying model name
     */

    public String getModel() {
        return this.model;
    }

    /**
     * Confirms whether the bristles of this brush are rounded.
     * 
     * @return if the brush tips are round or flat (upcharge)
     */

    public boolean isPolished() {
        return this.polished;
    }

    /**
     * Declares this brush's hardness.
     * 
     * @param hardness the new hardness value (0-5)
     */

    public void setHardness(int hardness) {
        if (hardness < 0) {
            this.hardness = 0;
        } else if (hardness > 5) {
            this.hardness = 5;
        }
        this.hardness = hardness;
    }

    /**
     * Calculates the consumer price of an order of brushes.
     * 
     * @param orderSize the number of items ordered
     * @param overseas whether the customer is overseas
     * @return the price in dollars and cents
     */

    public double shippingCost(int orderSize, boolean overseas) {
        double c;
        if (overseas) {
            c = UNIT_SHIPPING_COST_OVERSEAS * orderSize;
        } else {
            c = UNIT_SHIPPING_COST_LOCAL * orderSize;
        }
        if (orderSize > this.getInventory()) {
            c += STOCKING_COST;
        }
        if (orderSize > LARGE_ORDER) {
            c -= (c * LARGE_ORDER_DISCOUNT);
        }
        return c;
    }
}