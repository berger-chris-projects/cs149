/**
 * File input/output functionality for 'Teethbrush'/'ElectricTeethbrush' data types.
 * 
 * @author Vanessa P
 * @version 10/16/2023
 */

package product.io;


import java.io.File;
import java.io.IOException;
import java.util.Scanner;
import java.io.PrintWriter;

public class ProductFileProcessor {

    /**
     * Parses a Teethbrush object from a given CSV file.
     * 
     * @param the model name for this brush
     * @return Teethbrush the derived teethbrush object
     */
    public static Teethbrush readTeethbrush(String model) throws IOException {
        Teethbrush tb = null;
        Scanner read = null;
        int h, i = 0;
        boolean p = false;
        
        read = new Scanner(new File((model + ".bru")));
        i = read.nextInt();
        h = read.nextInt();
        p = read.nextBoolean();
        read.close();
        
        tb = new Teethbrush(model, h, p);
        tb.changeInventory(i);
        return tb;
    }

    /**
     * Parses an ElectricTeethbrush object from a given CSV file. 
     * 
     * @param the model name of this brush
     * @return ElectricTeethbrush the derived ElectricTeethbrush object
     */
    public static ElectricTeethbrush readElectricTeethbrush(String model) throws IOException {
        ElectricTeethbrush etb = null;
        int h, i = 0;
        boolean p, r, u = false;

        Scanner read = new Scanner(new File((model + ".bru")));
        i = read.nextInt();
        h = read.nextInt();
        p = read.nextBoolean();
        r = read.nextBoolean();
        u = read.nextBoolean();
        read.close();
        
        etb = new ElectricTeethbrush(model, h, p, r, u);
        etb.changeInventory(i);
        return etb;
    }
    
    /**
     * Creates and writes a .bru file with the attributes of a Teethbrush object.
     * 
     * @param product The brush being translated into a file
     * @throws IOException 
     */
    
    public static void writeTeethbrush(Teethbrush product) throws IOException {
        String filename = product.getModel() + ".bru";

        File file = new File(filename);
        PrintWriter pw = new PrintWriter(file);

        pw.write(String.format("%d,%d,%b\n", product.getInventory(),
                product.getHardness(), product.isPolished()));
        pw.close();
    }
    
    /**
     * Writes a CSV file listing an ElectricTeethbrush object's attributes.
     * 
     * @param product this brush's model name
     * @throws IOException
     */
    public static void writeElectricTeethbrush(ElectricTeethbrush product)
            throws IOException {
        String filename = product.getModel() + ".bru";

        File file = new File(filename);
        PrintWriter pw = new PrintWriter(file);

        pw.write(String.format("%d,%d,%b,%b,%b\n", product.getInventory(),
                product.getHardness(), product.isPolished(),
                product.isRechargeable(), product.isUltrasonic()));
        pw.close();
    }

    public static void main(String[] args) {

    }
}
