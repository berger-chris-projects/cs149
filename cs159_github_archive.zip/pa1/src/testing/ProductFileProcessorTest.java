package testing;

import static org.junit.jupiter.api.Assertions.*;
import java.io.File;
import org.junit.jupiter.api.Test;

/**
 * JUnit tests for the File Processor class.
 * 
 * @author Vanessa P
 * @version 10/16/2023
 */

class ProductFileProcessorTest {

    /**
     * Test case for the readTeethbrush() method.
     */
    @Test
    public static void readTeethbrushTest() {
        Teethbrush tb, tb2, bt, bt2;
        tb = new Teethbrush("716", 3, true);
        tb2 = new Teethbrush("0", 1, false);
        bt =  new Teethbrush("5509", 4, true);
        bt2 = new Teethbrush("31210", 5, false);
    }

    /**
     * Test case for the readElectricTeethbrush() method.
     */
    @Test
    public static void readElectricTeethbrushTest() {
        ElectricTeethbrush etb, etb2, bte, bte2;
        etb = new ElectricTeethbrush("E716", 3, true, false, false);
        etb2 = new ElectricTeethbrush("E0RU", 1, false, true, true);
        bte = new ElectricTeethbrush("E5509U", 4, true, false, true);
        bte2 = new ElectricTeethbrush("E31210R", 5, false, true, false);
    }

    /**
     * Test case for the writeTeethbrush() method.
     */
    @Test
    public static void writeTeethbrushTest() {

    }

    /**
     * Test case for the writeElectricTeethbrush() method.
     */
    @Test
    public static void writeElectricTeethbrushTest() {

    }

}
