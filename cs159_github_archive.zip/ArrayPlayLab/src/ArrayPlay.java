/**
 * A class lab working with arrays.
 * 
 * @author Chris Berger
 * @version 9/11/2023
 */
public class ArrayPlay {

    /** 
     * ArrayPlay's 'executable' main method.
     * 
     * @param args default main parameter
     */
    
    public static void main(String[] args) {
        int[] arr = new int[6];
        printArray(arr);

        Die d = new Die();
        for (int i = 0; i < 101; i++) {
            int ro = d.roll();
            arr[(ro - 1)]++;
        }
        for (int i = 0; i < 6; i++) {
            System.out.println((i + 1) + " was rolled " + arr[i] + " times.\n");
        }

        double[] jekyll = new double[10];
        double[] hyde = new double[10];
        for (int a = 0; a < jekyll.length; a++) {
            jekyll[a] = a;
        }
        printArray(jekyll, hyde);
    }
    /**
     * Prints information in an array.
     * 
     * @param a the integer array
     */
    
    public static void printArray(int[] a) {

        if (a == null) {
            System.out.println("null");
        } 
        
        if (a.length == 0) {
            return;
        }
        for (int i = 0; i < a.length; i++) {
            a[i] = -1;
            System.out.println("array[" + i + "] = -1");
        }
        for (int i = 0; i < a.length; i++) {
            a[i] = i;
            System.out.println(formMessage(a, i, ""));
        }
        for (int i = 0; i < a.length; i++) {
            a[i] = 0;
        }
        System.out.println("Array Play");
    }
    /**
     * Formats the arrays' message string.
     * 
     * @param a the integer array of entries
     * @param index the integer index of the array
     * @param format the desired format of the message
     * @return the properly formatted "array[_] = string
     */
    
    public static String formMessage(int[] a, int index, String format) {
        if (a == null) {
            System.out.println("null");
        } 
        
        if ((index >= a.length) || (index < 0)) {
            System.out.println("index out of bounds");
        }
        String s = "array[" + index + "] = " + a[index];
        return s;
    }
    /**
     * Prints two double arrays in the desired format.
     * 
     * @param a the first double array
     * @param b the second double array "[0.0, ...]"
     */
    
    public static void printArray(double[] a, double[] b) {
        if ((a == null) || (b == null)) {
            System.out.println("null");
        } 
        
        if (a.length != b.length) {
            return;
        }
        System.out.println("Before");
        for (int i = 0; i < 10; i++)
            System.out.println(i + " A1 = " + a[i] + " A2 = " + b[i]);
        for (int i = 0; i < 10; i++) {
            b[i] = a[i];
        }
        System.out.println("After");
        for (int i = 0; i < 10; i++)
            System.out.println(i + " A1 = " + a[i] + " A2 = " + b[i]);
        a[0] = 99.0;
        b[5] = 99.0;
        System.out.println("After Change");
        for (int i = 0; i < 10; i++)
            System.out.println(i + " A1 = " + a[i] + " A2 = " + b[i]);
    }
}