/**
 * A PhraseCypher uses a key phrase (containing all of the characters in the
 * alphabet) to encrypt and decrypt messages.
 * 
 * @author Vanessa Pierce
 * @version 9/25/2023
 */
public class PhraseCypher {
    // ________________________________________________1_________2______
    // _____________________________________012345678901234567890123456
    private static final String ALPHABET = " ABCDEFGHIJKLMNOPQRSTUVWXYZ";

    private String keyPhrase;

    /**
     * Explicit Value Constructor.
     * 
     * Note that the actual parameter must contain all of the characters in
     * ALPHABET ignoring case. In other words, the parameter "the quick brown
     * fox jumps over the lazy dog" and parameter "THE QUICK BROWN FOX JUMPS
     * OVER THE LAZY DOG" are both valid.
     * 
     * The constructor throws an IllegalArgumentException in 2 cases:
     * 
     * 1. when the actual parameter does not contain all of the characters
     * (ignoring case), in which case the exception's message will be:
     * "Missing:" followed immediately by the charOf() the first character in
     * ALPHABET that is not in key.
     * 
     * 2. when the actual parameter contains characters (ignoring case) that are
     * not found in ALPHABET, in which case the exception's message will be:
     * "Extra:" followed immediately by the first character in key that is not
     * in ALPHABET.
     * 
     * @param key The key phrase to use.
     * @throws IllegalArgumentException If key doesn't contain all of the
     * characters in ALPHABET, or if key contains a character that is not in
     * ALPHABET
     */
    public PhraseCypher(String key) throws IllegalArgumentException {
        if (key == null || key.length() == 0) {
            throw new IllegalArgumentException("Missing:" + charOf(0));
        }
        this.keyPhrase = key.toUpperCase();
        int[] incidence;
        incidence = new int[ALPHABET.length()];

        for (int i = 0; i < keyPhrase.length(); i++) {
            char c;
            c = keyPhrase.charAt(i);

            int v;
            v = valueOf(c);
            if (v < 0) {
                throw new IllegalArgumentException("Extra:" + c);
            }
            incidence[v]++;
        }

        for (int i = 0; i < incidence.length; i++) {
            if (incidence[i] <= 0) {
                throw new IllegalArgumentException("Missing:" + charOf(i));
            }
        }
    }

    /**
     * Decrypt an encrypted message.
     * 
     * Each element in the encrypted message is the 0-based index in the key
     * phrase. So, for example, for the key phrase "THE QUICK BROWN FOX JUMPS
     * OVER THE LAZY DOG", the array {20, 22, 5} would be decrypted as "JMU".
     * 
     * The decrypted message will contain as many characters as there are
     * elements in the encrypted secret. If the encrypted secret is null or
     * contains no elements, this method returns the empty String.
     * 
     * @param secret The encrypted secret
     * @return The decrypted message or the empty String
     */
    public String decrypt(int[] secret) {
        String result = "";
        if (secret == null) {
            return "";
        }
        if (secret.length == 0) {
            return "";
        }
        for (int i = 0; i < secret.length; i++) {
            if (secret[i] >= 0 && secret[i] < keyPhrase.length()) {
                result += keyPhrase.charAt(secret[i]);
            }
        }
        return result;
    }

    /**
     * Encrypt a message using the key phrase.
     * 
     * The message passed to the method can contain lower-case characters, but
     * it changes all lower-case characters with their upper-case counterparts.
     * So, for example, the message "JMU Dukes" will be changed to "JMU DUKES"
     * before it is encrypted.
     * 
     * Each char in the message is converted to the corresponding 0-based index
     * in the key phrase. When a char in the message is not in the key phrase
     * (which means it is also not in ALPHABET), the char is converted to -1.
     * 
     * So, for example, for the key phrase "THE QUICK BROWN FOX JUMPS OVER THE
     * LAZY DOG", the message "JMU DUKES" would be encrypted as {20, 22, 5, 3,
     * 40, 5, 8, 2, 24}.
     * 
     * The encryption will contain as many elements as there are characters in
     * the message. If the message is null or empty, this method returns an
     * array of length 0.
     * 
     * @param message The message to encrypt
     * @return The encryption
     */
    public int[] encrypt(String message) {
        if (message == null) {
            return new int[0];
        }
        if (message.isEmpty()) {
            return new int[0];
        }
        int n = 0;
        int[] result = new int[0];
        String text = "";

        text = message.toUpperCase();
        n = text.length();

        result = new int[n];

        for (int i = 0; i < text.length(); i++) {
            char c;
            int value;

            c = text.charAt(i);
            value = valueOf(c);

            if (value >= 0) {
                result[i] = keyPhrase.indexOf(c);
            } else {
                result[i] = -1;
            }
        }
        return result;
    }

    /**
     * Determine the char in the alphabet that has a specific integer value.
     * 
     * For example, the value 0 corresponds to the character ' ' and the value 2
     * corresponds to the character 'B'.
     * 
     * @param value The value
     * @return The char with that value (or the NUL char if the value is not in
     * the alphabet)
     */
    public static char charOf(int value) {
        if ((value < 0) || (value >= ALPHABET.length())) {
            return (char) 0;
        } else {
            return ALPHABET.charAt(value);
        }
    }

    /**
     * Determine the integer value of a given char in the alphabet.
     * 
     * For example, the character ' ' corresponds to the value 0 and the
     * character 'B' corresponds to the value 2.
     * 
     * @param c The char
     * @return The integer value (or -1 if the char is not in the alphabet)
     */
    public static int valueOf(char c) {
        return ALPHABET.indexOf(Character.toUpperCase(c));
    }
}
