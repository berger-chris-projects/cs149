import java.util.Random;

/**
 * Aisle subclass that limits aisle length and tracks customers missed.
 * 
 * @author Vanessa P
 * @version 10/16/23
 */

public class LimitedAisle extends Aisle {

    private int capacity;
    private int missed;

    /**
     * Explicit Value Constructor.
     * 
     * @param generator random number generation for checking out items
     * @param capacity maximum number of customers per aisle
     */

    public LimitedAisle(Random generator, int capacity) {
        super(generator);
        this.capacity = capacity;
        this.missed = 0;
    }

    /**
     * Permits a customer in line if the line isn't at capacity.
     * 
     * @param customer the customer (object) trying to get in line
     */

    @Override
    public void addCustomer(Customer customer) {
        if (super.lineLength() >= this.capacity) {
            this.missed++;
        }
        super.addCustomer(customer);
    }

    /**
     * Returns the current number of customers who have left the aisle.
     * 
     * @return the total number of customers who left due to line length
     */

    public int getMissedCustomers() {
        return this.missed;
    }
}
// at 1 customer per cashier, Bob's Grocery Mart can serve 
// up to 1450 customers.
// at 5 customers per cashier, Bob's Grocery Mart can serve 
// up to 1350 customers.
// at 20 customers per cashier, Bob's Grocery Mart can serve 
// up to 1100 customers. 
