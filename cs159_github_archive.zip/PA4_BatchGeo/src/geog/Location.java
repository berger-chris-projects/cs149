package geog;

/**
 * A data type denoting latitude and longitude coordinates.
 * 
 * @author Vanessa P.
 * @version 12/2/2023
 */

public class Location {
    private double longitude;
    private double latitude;

    /**
     * Explicit Value Constructor.
     * 
     * @param longitude the x coordinate
     * @param latitude the y coordinate
     */

    public Location(double longitude, double latitude) {
        this.longitude = longitude;
        this.latitude = latitude;
    }

    /**
     * Provides the longitudinal coordinate.
     * 
     * @return the x coordinate value
     */

    public double getLongitude() {
        return longitude;
    }

    /**
     * Provides the latitudinal coordinate.
     * 
     * @return the y coordinate value
     */

    public double getLatitude() {
        return latitude;
    }

    /**
     * Formats this location's coordinates with six decimal precision.
     * 
     * @return the formatted string
     */

    public String toString() {
        return String.format("%+9.6f,%+9.6f", longitude, latitude);
    }
}
