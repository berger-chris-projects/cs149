package testing;

import static org.junit.jupiter.api.Assertions.*;


import org.junit.jupiter.api.Test;
import geog.*;

class OnSegmentLocationTest {

    @Test
    void constructorAndGetters() {
        
        Location loc = new OnSegmentLocation("78907109", -78.936727,  +37.876257);
        
        assertEquals( -78.936727,  loc.getLongitude());
        assertEquals( +37.876257,  loc.getLatitude());
    }

    @Test
    void compareTo() {
        
        OnSegmentLocation a = new OnSegmentLocation("78907109", -78.936727,  +37.876257);
        OnSegmentLocation b = new OnSegmentLocation("75739596", -78.737162,  +38.380782);
        assertEquals(1, (int)Math.signum(a.compareTo(b)));

    }

}
