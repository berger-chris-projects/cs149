public class Car {
    private String make;
    private int year;
    private double speed;

    public Car(String m, int y) {
        this.make = m;
        this.year = y;
        this.speed = 0;
    }

    public String toString() {
        String car = ("A " + this.year + " " + this.make + " that is going "
                + this.speed + " mph");
        return car;
    }

    public String getMake() {
        return this.make;
    }

    public double getSpeed() {
        return this.speed;
    }

    public int getYear() {
        return this.year;
    }

    /**
     * Accelerates the car by 5 m.p.h. and returns the speed (before and after).
     * 
     * @return a string of before and after speed
     */

    public String accelerate() {
        String rope;
        if (this.speed < 150.0) {
            rope = this.speed + " + 5.0 = " + (this.speed + 5.0);
            this.speed += 5.0;
            return rope;
        } else {
            this.speed = 150.0;
            rope = this.speed + " + 0.0 = " + this.speed;
            return rope;
        }
    }

    /**
     * Decelerates the car by 5 m.p.h. or to a stop.
     */

    public void brake() {
        if (this.speed >= 5.0) {
            this.speed -= 5.0;
        } else {
            this.speed = 0.0;
        }
    }
}
