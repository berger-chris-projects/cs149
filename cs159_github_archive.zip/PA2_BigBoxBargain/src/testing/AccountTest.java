/**
 * JUnit test class for the (CSVRepresentable) superclass Account.
 * 
 * @author Vanessa P
 * @version 10/30/2023
 */

package testing;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import membership.Account;

class AccountTest {

    /**
     * JUnit test case for the constructor and get attribute methods.
     */

    @Test
    public void constructorsGettersTest() {
        Account a1, a2, a3, a4;
        a1 = new Account();
        a2 = new Account(45.98, 13.09);
        a3 = new Account(0.00, 0.00);
        a4 = new Account(9999.99, 10.00);

        assertEquals(10.00, a4.getCreditsUsed());
        assertEquals(0.01, a3.getRewardPercentage());
        assertEquals(0.01, a1.getRewardPercentage());
        assertEquals(0.00, a3.getPurchases());
        assertEquals(0.00, a1.getCreditsUsed());
        assertEquals(45.98, a2.getPurchases());
        assertEquals(a2.getCreditsUsed() - 3.09, a4.getCreditsUsed());
    }

    /**
     * JUnit test case for the CSVRepresentable.toCSV() method.
     */

    @Test
    public void toCSVTest() {
        Account a1, a2, a3, a4;
        a1 = new Account();
        a2 = new Account(45.98, 13.09);
        a3 = new Account(0.00, 0.00);
        a4 = new Account(9999.99, 10.00);
        String s1 = a1.toCSV(), s2 = a2.toCSV(), s3 = a3.toCSV(),
                s4 = a4.toCSV();

        assertEquals("0.00,0.00", s1);
        assertEquals("45.98,13.09", s2);
        assertEquals("0.00,0.00", s3);
        assertEquals("9999.99,10.00", s4);
    }

    /**
     * JUnit test case for the CSVRepresentable.fromCSV() method.
     */

    @Test
    public void fromCSVTest() {
        Account a1, a2, a3, a4;
        a1 = new Account();
        a2 = new Account();
        a3 = new Account();
        a4 = new Account();
        String s2 = "45.98,13.09", s3 = "0.00,0.00", s4 = "9999.99,10.00";
        a2.fromCSV(s2);
        a3.fromCSV(s3);
        a4.fromCSV(s4);
        assertEquals(0.00, a1.availableCredit());
        assertEquals(45.98, a2.getPurchases());
        assertEquals(13.09, a2.getCreditsUsed());
        assertEquals(0.00, a3.availableCredit());
        assertEquals(9999.99, a4.getPurchases());
        assertEquals(true, a4.canUseExpressLine());
    }

    /**
     * JUnit test case for the canUseExpressLine() method.
     */

    @Test
    public void canUseExpressLineTest() {
        Account a1, a2, a3, a4;
        a1 = new Account();
        a2 = new Account(4500.98, 13.09);
        a3 = new Account(0.00, 1000.00);
        a4 = new Account(9999.99, 10.00);
        assertTrue(a2.canUseExpressLine());
        assertFalse(a1.canUseExpressLine());
        assertTrue(a4.canUseExpressLine());
        assertFalse(a3.canUseExpressLine());
    }

    /**
     * JUnit test case for the availableCredit() method.
     */

    @Test
    public void availableCreditTest() {
        Account a1, a2, a3, a4;
        a1 = new Account(3000.00, 14.6); // 3000 * 0.01 = 30 - 14.50= 15.40
        a2 = new Account(451.00, 4.49); // 451 * 0.01 = 4.51 - 4.49 = 0.02
        a3 = new Account(101.00, 10.00); // 101 * 0.01 = 1.01 - 10 = -8.99
        a4 = new Account(99.99, 1.00); // 99.99 * 0.01 = 0.9999 - 1.00 = -0.0001
        double t = Math.abs(0.02 - a2.availableCredit());
        assertEquals(15.40, a1.availableCredit());
        assertEquals(0.02 - Math.abs(t), a2.availableCredit());
        assertEquals(0.00, a3.availableCredit());
        assertEquals(0.00, a4.availableCredit());
    }

    /**
     * JUnit test case for the purchase() and the protected increase attribute
     * methods.
     */

    @Test
    public void purchaseTest() {
        Account a1, a2, a3, a4;
        a1 = new Account();
        a2 = new Account(450.00, 5.00); // avail cred = 4.5 - 5 = -0.5 (is 0.00)
        a3 = new Account(101.00, 10.00);
        a4 = new Account(200.00, 1.00); // avail cred = 2 - 1.00 = 1.00
        assertEquals(50, a1.purchase(50.00, false));
        assertEquals(4.50, a2.purchase(4.50, true)); // p = 454.5 c = 
        assertEquals(0.00, a3.purchase(-100.00, false));
        assertEquals(0.00, a4.purchase(1.00, true));
        Account a5 = new Account(600.00, 0.00); // avail cred = 6.90
        assertEquals(0.00, a5.purchase(5.00, true)); // 
        assertEquals(50.00, a1.getPurchases());
        assertEquals(5.00, a2.getCreditsUsed());
        assertEquals(600.0, a5.getPurchases());
        a1 = new Account(15.00, 5000.00); // AC = 150 - 5 = 145
        assertEquals(0.00, a1.purchase(-0.50, true));
    }

    /**
     * JUnit test case for the toString() method.
     */

    @Test
    public void toStringTest() {
        Account a1, a2, a3, a4;
        a1 = new Account();
        a2 = new Account(45.98, 13.09); // AC = 0.4598 - 13.09
        a3 = new Account(55.00, 0.55); // AC = 0.55 - 0.55
        a4 = new Account(9999.99, 10.00); // AC = 99.99 - 10.00
        String s1 = "Purchases: 0.00\nCredits Used: 0.00\nCredits available: 0.00";
        String s2 = "Purchases: 45.98\nCredits Used: 13.09\nCredits available: 0.00";
        String s3 = "Purchases: 55.00\nCredits Used: 0.55\nCredits available: 0.00";
        String s4 = "Purchases: 9999.99\nCredits Used: 10.00\nCredits available: 90.00";
        assertEquals(s1, a1.toString());
        assertEquals(s2, a2.toString());
        assertEquals(s3, a3.toString());
        assertEquals(s4, a4.toString());
    }
}
