/**
 * Provides information and prices for orders at Duke 'n' Donuts.
 * 
 * @author Chris Berger
 * @version 9/6/2023
 */
public class DonutPricer {
    private static final int BOX_SIZE = 12;
    private static final double PRICE_PER_BOX = 9.99;
    private static final double PRICE_PER_INDIVIDUAL = 0.99;

    /**
     * Returns whether or not an order needs an extra donut box.
     * 
     * @param numberOfDonuts the number of donuts ordered
     * 
     * @return a boolean True or False if an order needs an extra box.
     */
    public static boolean needAnExtraBox(int numberOfDonuts) {
        if (numberOfExtras(numberOfDonuts) > 0) {
            return true;
        } 
        return false;
    }

    /**
     * Returns the necessary number of boxes for an order.
     * 
     * @param numberOfDonuts the number of donuts ordered.
     * 
     * @return the total number of boxes needed for an order, full or partially
     * full.
     */
    public static int numberOfBoxes(int numberOfDonuts) {
        if (numberOfDonuts <= 0) {
            return 0;
        }
        int bocks = (numberOfDonuts / BOX_SIZE);
        if (needAnExtraBox(numberOfDonuts)) {
            bocks++;
        }
        return bocks;
    }

    /**
     * Returns how many donut boxes will be full in an order.
     * 
     * @param numberOfDonuts the number of donuts ordered
     * 
     * @return the number of full boxes (boxes with DonutPricer.BOX_SIZE donuts)
     */
    public static int numberOfFullBoxes(int numberOfDonuts) {
        int bocks = (numberOfDonuts / BOX_SIZE);
        if (numberOfDonuts <= 0) {
            return 0;
        }
        if ((bocks == 0) && (numberOfDonuts == 0)) {
            return 0;
        } else {
            return bocks;
        }
    }

    /**
     * Returns the number of donuts that can't fill a box of
     * DonutPricer.BOX_SIZE.
     * 
     * @param numberOfDonuts the number of donuts ordered.
     * 
     * @return the number of extra donuts.
     */
    public static int numberOfExtras(int numberOfDonuts) {
        if (numberOfDonuts <= 0) {
            return 0;
        }
        return (numberOfDonuts % BOX_SIZE);
    }

    /**
     * Automatically prices an order at Duke 'n' Donuts.
     * 
     * @param numberOfDonuts the number of donuts in an order.
     * 
     * @return the price, in dollars and cents, of an order of donuts.
     */
    public static double priceFor(int numberOfDonuts) {
        double cost;
        if (numberOfDonuts <= 0) {
            return 0.0;
        }
        int bocks = numberOfFullBoxes(numberOfDonuts);
        int xtras = numberOfExtras(numberOfDonuts);
        cost = (bocks * PRICE_PER_BOX) + (xtras * PRICE_PER_INDIVIDUAL);
        return cost;
    }
}
