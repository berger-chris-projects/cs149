package geog;

/**
 * A data type for houses on Segment objects with coordinates.
 * 
 * @author Vanessa P
 * @version 12/2/2023
 */

public class OnSegmentLocation extends Location
        implements Comparable<OnSegmentLocation> {
    private String id;

    /**
     * Explicit Value Constructor.
     * 
     * @param id the identifiable string of this object
     * @param longitude the x coordinate
     * @param latitude the y coordinate
     */

    public OnSegmentLocation(String id, double longitude, double latitude) {
        super(longitude, latitude);
        this.id = id;
    }

    /**
     * Compares two OnSegmentLocations for ID similarity.
     * 
     * @param o the other OnSegmentLocation object
     * @return neg/pos/zero if this ID is less/more/equal to the other
     */
    @Override
    public int compareTo(OnSegmentLocation o) {
        return (this.id.compareTo(o.id));
    }
}
