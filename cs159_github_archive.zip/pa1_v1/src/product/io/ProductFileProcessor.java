/**
 * File input/output functionality for 'Teethbrush'/'ElectricTeethbrush' 
 * data types.
 * 
 * @author Vanessa P
 * @version 10/16/2023
 */

package product.io;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

import product.Teethbrush;
import product.ElectricTeethbrush;

import java.io.PrintWriter;

/**
 * A utility class for our brushes and their methods.
 * 
 * @author Vanessa P
 * @version 10/25/2023
 */

public class ProductFileProcessor {

    /**
     * Parses a Teethbrush object from a given CSV file.
     * 
     * @param model the model name for this brush
     * @return the derived teethbrush object
     */
    public static Teethbrush readTeethbrush(String model) throws IOException {
        Teethbrush tb;
        File file = new File(model + ".bru");
        Scanner read = new Scanner(file);
        int h = 0;
        int i = 0;
        boolean p = false;
        i = read.nextInt();
        h = read.nextInt();
        p = read.nextBoolean();
        read.close();

        tb = new Teethbrush(model, h, p);
        tb.changeInventory(i);
        return tb;
    }

    /**
     * Parses an ElectricTeethbrush object from a given CSV file.
     * 
     * @param model the model name of this brush
     * @return the derived ElectricTeethbrush object
     */
    public static ElectricTeethbrush readElectricTeethbrush(String model)
            throws IOException {
        ElectricTeethbrush etb;
        File file = new File(model + ".bru");
        Scanner read = new Scanner(file);
        int h, i = 0;
        boolean p, r, u = false;
        i = read.nextInt();
        h = read.nextInt();
        p = read.nextBoolean();
        r = read.nextBoolean();
        u = read.nextBoolean();
        read.close();

        etb = new ElectricTeethbrush(model, h, p, r, u);
        etb.changeInventory(i);
        return etb;
    }

    /**
     * Creates and writes a .bru file with the attributes of a Teethbrush
     * object.
     * 
     * @param product The brush being translated into a file
     * @throws IOException input output failure
     */

    public static void writeTeethbrush(Teethbrush product) throws IOException {
        String filename = product.getModel() + ".bru";

        File file = new File(filename);
        PrintWriter pw = new PrintWriter(file);

        pw.write(String.format("%d,%d,%b\n", product.getInventory(),
                product.getHardness(), product.isPolished()));
        pw.close();
    }

    /**
     * Writes a CSV file listing an ElectricTeethbrush object's attributes.
     * 
     * @param product this brush's model name
     * @throws IOException input output failure
     */
    public static void writeElectricTeethbrush(ElectricTeethbrush product)
            throws IOException {
        String filename = product.getModel() + ".bru";

        File file = new File(filename);
        PrintWriter pw = new PrintWriter(file);

        pw.write(String.format("%d,%d,%b,%b,%b\n", product.getInventory(),
                product.getHardness(), product.isPolished(),
                product.isRechargeable(), product.isUltrasonic()));
        pw.close();
    }
}
