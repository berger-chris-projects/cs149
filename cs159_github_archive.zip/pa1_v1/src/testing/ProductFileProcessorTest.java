package testing;

import static org.junit.jupiter.api.Assertions.*;
import java.io.File;
import java.io.IOException;

import org.junit.jupiter.api.Test;

import product.Teethbrush;
import product.ElectricTeethbrush;
import product.io.ProductFileProcessor;

/**
 * JUnit tests for the File Processor class.
 * 
 * @author Vanessa P
 * @version 10/16/2023
 */

class ProductFileProcessorTest {

    /**
     * Test case for the built-in constructor method.
     */
    @Test
    public void constructTest() {
        ProductFileProcessor pfp = new ProductFileProcessor();
    }

    /**
     * Test case for the Teethbrush read/write methods.
     */
    @Test
    public void fileIOTeethbrushTest() {
        Teethbrush tb, tb2, bt;
        tb = new Teethbrush("716", 3, true);
        tb2 = new Teethbrush("0", 1, false);
        bt = new Teethbrush("5509", 4, true);

        try {
            ProductFileProcessor.readTeethbrush("random words!!");
        } catch (IOException ioe) {
            System.out.println(ioe);
        }

        try {
            ProductFileProcessor.writeTeethbrush(tb);
            Teethbrush t1 = ProductFileProcessor.readTeethbrush(tb.getModel());
            assertEquals(tb.getModel(), t1.getModel());
            assertEquals(tb.getInventory(), t1.getInventory());
            assertEquals(tb.isPolished(), t1.isPolished());
        } catch (IOException ioe) {
            System.out.println(ioe);
        }

        try {
            ProductFileProcessor.writeTeethbrush(tb2);
            Teethbrush t2 = ProductFileProcessor.readTeethbrush(tb2.getModel());
            assertEquals(tb2.getModel(), t2.getModel());
            assertEquals(tb2.getInventory(), t2.getInventory());
            assertEquals(tb2.isPolished(), t2.isPolished());
        } catch (IOException ioe) {
            System.out.println(ioe);
        }

        try {
            ProductFileProcessor.writeTeethbrush(bt);
            Teethbrush t3 = ProductFileProcessor.readTeethbrush(bt.getModel());
            assertEquals(bt.getModel(), t3.getModel());
            assertEquals(bt.getInventory(), t3.getInventory());
            assertEquals(bt.isPolished(), t3.isPolished());
        } catch (IOException ioe) {
            System.out.println(ioe);
        }

        try {
            ProductFileProcessor.writeTeethbrush(
                    new Teethbrush("poopoo and dookey", 3, false));
            ProductFileProcessor.readTeethbrush("random words!!");
        } catch (IOException ioe) {
            System.out.println(ioe);
        }
    }

    /**
     * Test case for the ElectricTeethbrush read/write methods.
     */
    @Test
    public void fileIOElectricTeethbrushTest() {
        ElectricTeethbrush etb, etb2, bte;
        etb = new ElectricTeethbrush("E716", 3, true, false, false);
        etb2 = new ElectricTeethbrush("E0", 1, false, true, true);
        bte = new ElectricTeethbrush("E5509", 4, true, false, true);

        try {
            ProductFileProcessor.readElectricTeethbrush("Mark 1");
        } catch (IOException ioe) {
            System.out.println(ioe);
        }

        try {
            ProductFileProcessor.writeElectricTeethbrush(etb);
            ElectricTeethbrush e1 = ProductFileProcessor
                    .readElectricTeethbrush(etb.getModel());
            assertEquals(etb.getModel(), e1.getModel());
            assertEquals(etb.getInventory(), e1.getInventory());
            assertEquals(etb.isPolished(), e1.isPolished());
            assertEquals(etb.isRechargeable(), e1.isRechargeable());
            assertEquals(etb.isUltrasonic(), e1.isUltrasonic());
        } catch (IOException ioe) {
            System.out.println(ioe);
        }

        try {
            ProductFileProcessor.writeElectricTeethbrush(etb2);
            ElectricTeethbrush e2 = ProductFileProcessor
                    .readElectricTeethbrush(etb2.getModel());
            assertEquals(etb2.getModel(), e2.getModel());
            assertEquals(etb2.getInventory(), e2.getInventory());
            assertEquals(etb2.isPolished(), e2.isPolished());
            assertEquals(etb2.isRechargeable(), e2.isRechargeable());
            assertEquals(etb2.isUltrasonic(), e2.isUltrasonic());
        } catch (IOException ioe) {
            System.out.println(ioe);
        }

        try {
            ProductFileProcessor.writeElectricTeethbrush(bte);
            ElectricTeethbrush e3 = ProductFileProcessor
                    .readElectricTeethbrush(bte.getModel());
            assertEquals(bte.getModel(), e3.getModel());
            assertEquals(bte.getInventory(), e3.getInventory());
            assertEquals(bte.isPolished(), e3.isPolished());
            assertEquals(bte.isRechargeable(), e3.isRechargeable());
            assertEquals(bte.isUltrasonic(), e3.isUltrasonic());
        } catch (IOException ioe) {
            System.out.println(ioe);
        }
    }

}
