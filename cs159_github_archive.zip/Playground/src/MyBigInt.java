import java.math.BigInteger;

/**
 * A BigInteger that allows comma-separated strings.
 * 
 * @author
 * @version
 */
@SuppressWarnings("serial")
public class MyBigInt extends BigInteger {

    /**
     * Constructs a MyBigInt from the given string.
     * 
     * @param val decimal representation of MyBigInt
     */
    public MyBigInt(String val) {
        // remove comma characters
        super(val.replace(",", ""));
    }

    @Override
    public String toString() {
        // start with the decimal representation
        String str = super.toString();
        StringBuilder sb = new StringBuilder(str);

        // insert comma separators every three digits
        for (int i = sb.length() - 3; i > 0; i -= 3) {
            sb.insert(i, ',');
        }
        return sb.toString();
    }

    /**
     * Example uses of MyBigInt objects.
     * 
     * @param args command-line arguments
     */
    public static void main(String[] args) {

//        BigInteger bi = new BigInteger("123456789");
//        System.out.println(bi);

//        MyBigInt bi = new MyBigInt("123456789");
//        System.out.println(bi);

//        BigInteger bi = new BigInteger("123,456,789");
//        System.out.println(bi);

//        MyBigInt bi = new MyBigInt("123,456,789");
//        System.out.println(bi);

        BigInteger bi1 = new BigInteger("123456789");
        MyBigInt bi2 = new MyBigInt("123,456,789");
        System.out.println(bi1.equals(bi2));
        System.out.println(bi2.equals(bi1));

    }

}
