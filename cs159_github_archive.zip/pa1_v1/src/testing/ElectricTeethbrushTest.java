package testing;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import product.ElectricTeethbrush;

/**
 * JUnit tests for the Electric Teethbrush subclass.
 * 
 * @author Vanessa P
 * @version 10/16/2023
 */

class ElectricTeethbrushTest {

    /**
     * Test case for the overriden cost() method.
     */
    @Test
    public void costTest() {
        ElectricTeethbrush etb, etb2, bte, bte2;
        etb = new ElectricTeethbrush("E716", 3, true, false, false); // 20.25
        etb2 = new ElectricTeethbrush("E0RU", 1, false, true, true); // 45.50
        bte = new ElectricTeethbrush("E5509U", 4, true, false, true); // 30.75
        bte2 = new ElectricTeethbrush("E31210R", 5, false, true, false); // 37.50

        assertEquals(etb.cost(), 20.25);
        assertEquals(etb2.cost(), 45.50);
        assertEquals(bte.cost(), 30.75);
        assertEquals(bte2.cost(), 37.50);
    }

    /**
     * Test case for the isRechargeable() method.
     */
    @Test
    public void isRechargeableTest() {
        ElectricTeethbrush etb, etb2, bte, bte2;
        etb = new ElectricTeethbrush("E716", 3, true, false, false);
        etb2 = new ElectricTeethbrush("E0RU", 1, false, true, true);
        bte = new ElectricTeethbrush("E5509U", 4, true, false, true);
        bte2 = new ElectricTeethbrush("E31210R", 5, false, true, false);

        assertFalse(etb.isRechargeable());
        assertTrue(etb2.isRechargeable());
        assertFalse(bte.isRechargeable());
        assertTrue(bte2.isRechargeable());
        assertEquals(etb.isRechargeable(), bte.isRechargeable());
        assertEquals(etb2.isRechargeable(), bte2.isRechargeable());
    }

    /**
     * Test case for the isUltrasonic() method.
     */
    @Test
    public void isUltrasonicTest() {
        ElectricTeethbrush etb, etb2, bte, bte2;
        etb = new ElectricTeethbrush("E716", 3, true, false, false);
        etb2 = new ElectricTeethbrush("E0RU", 1, false, true, true);
        bte = new ElectricTeethbrush("E5509U", 4, true, false, true);
        bte2 = new ElectricTeethbrush("E31210R", 5, false, true, false);

        assertEquals(etb.isUltrasonic(), false);
        assertEquals(etb2.isUltrasonic(), true);
        assertEquals(bte.isUltrasonic(), true);
        assertEquals(bte2.isUltrasonic(), false);
        assertEquals(etb.isUltrasonic(), bte2.isUltrasonic());
        assertEquals(etb2.isUltrasonic(), bte.isUltrasonic());
    }

}
