import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

/**
 * Exercises for practicing with Java collection types.
 * 
 * @author Vanessa P
 * @version 11/23/2023
 */
public class CollectionExercises {

    /**
     * This method removes all values from the provided list that are smaller
     * than the indicated integer. The remaining elements retain their original
     * ordering.
     * 
     * @param list the list of integers
     * @param minVal the minimum value to retain
     */
    public static void removeSmallInts(List<Integer> list, int minVal) {
        Iterator<Integer> i = list.iterator();
        while (i.hasNext()) {
            if (i.next() < minVal) {
                i.remove();
            }
        }
    }

    /**
     * This method returns true if the provided collection contains any
     * duplicate elements.
     * 
     * @param ints a collection of integers
     * @return true if ints contains duplicates, false otherwise
     */
    public static boolean containsDuplicates(Collection<Integer> ints) {
        HashSet<Integer> s = new HashSet<Integer>(ints);
        return s.size() < ints.size();
    }

    /**
     * This method returns an ArrayList containing all elements that appear in
     * either of the two collection arguments. There will be no duplicate values
     * in the resulting ArrayList. The values in the returned ArrayList may be
     * in any order.
     * 
     * For example, if the two arguments contain {2, 1, 2, 3} and {3, 4, 4, 5},
     * the returned ArrayList will contain {1, 2, 3, 4, 5}. The original
     * collections will not be modified.
     * 
     * @param ints1 the first collection
     * @param ints2 the second collection
     * @return An ArrayList containing the integers that appear in either
     * collection.
     */
    public static ArrayList<Integer> inEither(Collection<Integer> ints1,
            Collection<Integer> ints2) {
        // This can be done with no loops.
        ints1.addAll(ints2);
        HashSet<Integer> ess = new HashSet<>(ints1);
        ArrayList<Integer> ali = new ArrayList<Integer>(ess);
        return ali;
    }

    /**
     * This method returns an ArrayList containing all elements that appear in
     * both of the two collection arguments. There will be no duplicate values
     * in the resulting ArrayList. The values in the returned ArrayList may be
     * in any order. For example, if the two arguments contain {2, 1, 2, 3} and
     * {3, 4, 4, 5}, the returned ArrayList will contain {3}. The original
     * collections will not be modified.
     * 
     * @param ints1 the first collection
     * @param ints2 the second collection
     * @return An ArrayList containing the integers that appear in both
     * collections.
     */
    public static ArrayList<Integer> inBoth(Collection<Integer> ints1,
            Collection<Integer> ints2) {
        Iterator<Integer> i = ints1.iterator();
        HashSet<Integer> temporary = new HashSet<Integer>();
        while (i.hasNext()) {
            int first = i.next();
            if (ints2.contains(first)) {
                temporary.add(first);
            }
        }
        ArrayList<Integer> real = new ArrayList<Integer>(temporary);
        return real;
    }

    /**
     * This method returns the String that appears most frequently in the
     * provided list. For example, if the input list contains the elements
     * {"Bob", "Alice", "Bob"}, this method will return "Bob". If there are
     * ties, any of the most frequently occurring elements may be returned.
     * 
     * @param list a list of Strings
     * @return the most frequently occurring String
     */
    public static String mostFrequent(List<String> list) {
        // You should solve this problem in two stages: First iterate through
        // the list to count every String. Then iterate through your counts
        // to find the largest. You'll need a collection that allows you to
        // store a mapping from Strings to counts.
        // Remember: no nested for-loops are allowed.
        String frequent = "";
        HashMap<String, Integer> m = new HashMap<>(list.size());
        if (list.isEmpty()) {
            return null;
        } else {
            for (String s : list) {
                if (!m.keySet().contains(s)) {
                    m.put(s, 1);
                } else {
                    m.put(s, m.get(s) + 1);
                }
            }
            int max = 0;
            for (String k : m.keySet()) {
                if (m.get(k) > max) {
                    max = m.get(k);
                    frequent = k;
                }
            }
            return frequent;
        }
    }

}
