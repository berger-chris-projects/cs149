package membership;

import java.util.Scanner;
import io.CSVRepresentable;

/**
 * Specifies the (CSVRepresentable) superclass at Big Box Bargains.
 * 
 * @author Vanessa P
 * @version 10/30/2023
 */


public class Account implements CSVRepresentable {
    private double creditsUsed;
    private double purchases;

    /**
     * New Account Value Constructor at BBB.
     */
    public Account() {
        this.purchases = 0.00;
        this.creditsUsed = 0.00;
    }

    /**
     * Explicit Value Constructor.
     * 
     * @param purchases this account holder's purchases
     * @param creditsUsed amount of store credit this account holder has used
     */
    public Account(double purchases, double creditsUsed) {
        this.purchases = purchases;
        this.creditsUsed = creditsUsed;
    }

    /**
     * Derives an account owner's total purchases and used store credit from a
     * CSV file.
     * 
     * @param s the new comma-separated fields of this object
     * @return the unclosed Scanner resource for future tokenizing
     */
    public Scanner fromCSV(String s) {
        Scanner read;
        double p, c;

        read = new Scanner(s);
        read.useDelimiter(",");
        p = read.nextDouble();
        c = read.nextDouble();
        this.purchases = p;
        this.creditsUsed = c;
        return read;
    }

    /**
     * Formats this account owner's purchases and used store credit as
     * comma-separated values.
     * 
     * @return this object's comma-separated value representation
     */
    public String toCSV() {
        return String.format("%.2f,%.2f", this.getPurchases(),
                this.getCreditsUsed());
    }

    /**
     * The amount of store credit this account's owner can still use.
     * 
     * @return this account owner's available BBB store credit.
     */

    public double availableCredit() {
        double c = (getPurchases() * getRewardPercentage()) - getCreditsUsed();
        if (c < 0.00) {
            c = 0.00;
        }
        return c;
    }

    /**
     * Decides whether this account's owner can use the express check-out line.
     * 
     * @return T/F if this customer can use a faster lane to check-out
     */

    public boolean canUseExpressLine() {
        return (this.getPurchases() > 1000);
    }

    /**
     * Returns the to-date total store credit this customer has used.
     * 
     * @return the amount of store credit this customer has used
     */

    public double getCreditsUsed() {
        return this.creditsUsed;
    }

    /**
     * Returns the to-date total money spent at Big Box Bargains.
     * 
     * @return the amount of money spent on purchases
     */

    public double getPurchases() {
        return this.purchases;
    }

    /**
     * Denotes the percent of any order this customer is owed in reward credit.
     * 
     * @return the percent of an order the customer earns in store credit
     */

    public double getRewardPercentage() {
        return 0.01;
    }

    /**
     * Updates the amount of store credit used by this customer in their account
     * 
     * @param credit the credit used in this order
     */

    protected void increaseCreditsUsed(double credit) {
        if (credit > 0.00) {
            creditsUsed += credit;
        }
    }

    /**
     * Updates the customer's purchase amount in their account.
     * 
     * @param amount the money paid on this order
     */

    protected void increasePurchases(double amount) {
        if (amount > 0.00) {
            purchases += amount;
        }
    }

    /**
     * Specifies a regular account's purchase at Big Box Bargains.
     * 
     * @param amount the cashier total, in dollars and cents
     * @param applyCredits if the customer wants to use store credit
     * @return the final amount due to the customer, in dollars and cents
     */

    public double purchase(double amount, boolean applyCredits) {
        if (amount > 0) {
            double c = amount;
            if (applyCredits) {
                double ac = availableCredit();
                if (availableCredit() > c) {
                    ac = c;
                }
                increaseCreditsUsed(ac);
                c -= ac;
            }
            increasePurchases(c);

            return c;
        }
        return 0.00;
    }

    /**
     * Formats this account's propertie as a helfpul string.
     * 
     * @return the purchases, credits used and available for this account
     */

    public String toString() {
        return String.format(
                "Purchases: %.2f\nCredits Used: %.2f\nCredits available: %.2f",
                this.getPurchases(), this.getCreditsUsed(),
                this.availableCredit());
    }
}
