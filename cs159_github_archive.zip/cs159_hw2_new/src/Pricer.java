/**
 * Prices products at Duke 'n' Donuts.
 * 
 * @author Chris Berger
 * @version 9/13/2023
 */
public class Pricer {
    private int boxSize;
    private double pricePerBox;
    private double pricePerIndividual;

    /**
     * Constructor for Pricer() class.
     * 
     * @param boxSize the amount of items that fill a box
     * @param pricePerBox the price (dollars, cents0 of a full box
     * @param pricePerIndividual the price (dollars, cents) of one item
     */
    public Pricer(int boxSize, double pricePerBox, double pricePerIndividual) {
        this.boxSize = boxSize;
        this.pricePerBox = pricePerBox;
        this.pricePerIndividual = pricePerIndividual;
    }

    /**
     * Checks if the order doesn't neatly fit into boxes.
     * 
     * @param numberOfItems the number of whatever item in an order.
     * 
     * @return true or false (does the order need an extra box).
     */
    public boolean needAnExtraBox(int numberOfItems) {
        if (numberOfItems <= 0) {
            return false;
        }
        return (numberOfItems % boxSize != 0);
    }

    /**
     * Calculates the total number of boxes an order needs.
     * 
     * @param numberOfItems the number of whatever item in the order.
     * 
     * @return the number of boxes for the order.
     */
    public int numberOfBoxes(int numberOfItems) {
        if (numberOfItems <= 0) {
            return 0;
        }
        int b = numberOfFullBoxes(numberOfItems);
        int ex = numberOfExtras(numberOfItems);
        if (b == 0) {
            if (ex == 0) {
                return 0;
            } else {
                return 1;
            }
        } else {
            if (ex == 0) {
                return b;
            } else {
                return (b + 1);
            }
        }
    }

    /**
     * Indicates the amount of full boxes an order will have.
     * 
     * @param numberOfItems the number of whatever item in an order.
     * 
     * @return the number of full boxes an order takes.
     */
    public int numberOfFullBoxes(int numberOfItems) {
        if (numberOfItems <= 0) {
            return 0;
        }
        int b = 0;
        b = (numberOfItems / boxSize);
        return b;
    }

    /**
     * Outputs the number of extra items of an order.
     * 
     * @param numberOfItems the number of whatever item in an order.
     *
     * @return the amount of items that won't fit into a full box.
     */
    public int numberOfExtras(int numberOfItems) {
        if (numberOfItems <= 0) {
            return 0;
        }
        return (numberOfItems % boxSize);
    }

    /**
     * Calculates the total dollar amount a customer must pay for their order.
     * 
     * @param numberOfItems the number of whatever item in an order.
     * 
     * @return the price (dollars and cents) of an order at Duke 'n' Donuts.
     */
    public double priceFor(int numberOfItems) {
        if (numberOfItems <= 0) {
            return 0;
        }
        double price = 0.00;
        double bocks = (numberOfFullBoxes(numberOfItems) * pricePerBox);
        double extras = (numberOfExtras(numberOfItems) * pricePerIndividual);
        price = bocks + extras;
        return price;
    }

}
