
public class Filler {

 private int[][] table = {
 {0, 0, 0},
 {0, 0, 0},
 {0, 0, 0}
 };

 public Filler() {
 }

 public int fill(int row, int col, int value) {

 table[row][col] = value;
 if ((row-1) >= 0 && table[row-1][col] == 0)
 value = fill(row-1, col, value+1);
 if ((col+1) < 3 && table[row][col+1] == 0)
 value = fill(row, col+1, value+1);
 if ((row+1) < 3 && table[row+1][col] == 0)
 value = fill(row+1, col, value+1);
 if ((col-1) >= 0 && table[row][col-1] == 0)
 value = fill(row, col-1, value+1);

 return value;
 }

 public static void main(String[] args) {
     Filler f= new Filler();
     System.out.println(f.fill(2, 1, 1));
 }
}
