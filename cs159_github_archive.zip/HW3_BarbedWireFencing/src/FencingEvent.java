/**
 * The class specifics of a fencing event.
 * 
 * @author Chris Berger
 * @version 9/22/2023
 */
public enum FencingEvent {
    FOIL(500, false, BodyPart.TORSO, BodyPart.CROTCH),
    EPEE(775, false, BodyPart.values()),
    SABRE(500, true, BodyPart.HEAD, BodyPart.ARMS, BodyPart.TORSO);

    private BladePart[] bladeParts;
    private BodyPart[] targets;
    private int maximumWeight;

    /**
     * Explicit Value Constructor.
     * 
     * @param maximumWeight the maximum weight of an event's sword
     * @param edgeOK T/F if the edge of the sword counts
     * @param targets the legal body parts to hit in a fencing event
     */
    private FencingEvent(int maximumWeight, boolean edgeOK,
            BodyPart... targets) {

        this.maximumWeight = maximumWeight;
        BladePart[] parts = BladePart.values();
        if (edgeOK) {
            this.bladeParts = parts;
        } else {
            this.bladeParts = new BladePart[] {parts[1]};
        }
        this.targets = targets;
    }

    /**
     * Provides the maximum weight of a fencing event.
     * 
     * @return int the associated maximumWeight variable
     */
    public int getMaximumWeight() {
        return maximumWeight;
    }

    /**
     * Whether an area in a fencing event is legal.
     * 
     * @param target the BodyPart object (the body part hit)
     * @return boolean whether the provided BodyPart object is legal
     */
    public boolean isOnTarget(BodyPart target) {
        for (int i = 0; i < targets.length; i++) {
            if (target.equals(targets[i])) {
                return true;
            }
        }
        return false;
    }

    /**
     * Whether the part of the blade used counts.
     * 
     * @param part the BladePart that struck
     * @return whether or not the blade part is legal
     */
    public boolean isLegalBladePart(BladePart part) {
        if (part.equals(BladePart.EDGE)) {
            if (bladeParts.length != BladePart.values().length) {
                return false;
            }
            return true;
        }
        return true;
    }

    /**
     * Determines whether the specified blade part hitting the body part scores
     * a point.
     * 
     * @param part the body part getting hit
     * @param target the blade part hitting the fencer
     * @return boolean T/F the touch counts for a point
     */
    public boolean isScoringTouch(BladePart part, BodyPart target) {
        if (isOnTarget(target) && isLegalBladePart(part)) {
            return true;
        }
        return false;
    }
}