public class Trials {
    public static void tOne(String a, String b){
        String temp;
        temp = a;
        a    = b;
        b    = temp;
    }
    
    public static void tTwo(String[] c){
        String temp;
        temp = c[0];
        c[0] = c[1];
        c[1] = temp;
    }

    public static void main(String[] args){
        String duke = "Duke";
        String daisy = "Daisy";
        String[] dogs = {"Maple", "Major"};
        tOne(duke, daisy);
        tTwo(dogs);
        System.out.println(duke + " " + daisy);
        System.out.println(dogs[0] + " " + dogs[1]);
    }
}