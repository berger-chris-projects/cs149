import java.io.File;

/**
 * This is a utility class that provides some of the functionality of the Unix
 * ls and find commands.
 * 
 * @author Vanessa P
 * @version 11/12/2023
 */

public class DirectorySearcher {

    private final File start;

    /**
     * Construct a DirectorySearcher to search (or list files) inside a
     * particular directory.
     * 
     * @param path the name of the directory that will be searched
     */

    public DirectorySearcher(String path) {
        this.start = new File(path);
    }

    /**
     * List the contents of the start directory (but not subdirectories).
     */

    public void listDirectory() {
        File[] files = start.listFiles();
        for (File curFile : files) {
            System.out.print(curFile.getName());
            if (curFile.isDirectory()) {
                System.out.print("\t(Directory)");
            }
            System.out.println();
        }
    }

    /**
     * Recursively list the contents of the start directory and all of the
     * directories it contains.
     */

    public void listDirectories() {
        System.out.print(comprehensiveDirectoryList(start, 0));
    }

    /**
     * Lists all files in all directories from a given filepath.
     * 
     * @param d the beginning filepath
     * @param i stylistic indentation counter
     * 
     * @return all visible directories and files
     */

    public String comprehensiveDirectoryList(File d, int i) {
        String dir = d.getName();
        String o = "";
        String t = "";
        File[] files = d.listFiles();
        for (int a = 0; a < i; a++) {
            t += "\t";
        }
        o += t + dir + "/\n";
        for (int b = 0; b < files.length; b++) {
            if (files[b].isDirectory()) {
                o += comprehensiveDirectoryList(files[b], i + 1);
            } else {
                o = o + t + "\t" + files[b].getName() + "\n";
            }
        }
        return o;
    }

    /**
     * Specifies the directory filepath within which to search.
     * 
     * @param searchString the character sequence to search for
     */

    public void searchDirectories(String searchString) {
        searchDirectory(searchString, start);
    }

    /**
     * Displays all files under a given directory that contain a given character
     * sequence.
     * 
     * @param searchString the character sequence to search for
     * @param d the current subdirectory/file being searched over
     */
    public void searchDirectory(String searchString, File d) {
        String temp = d.getName();
        if (temp.contains(searchString)) {
            System.out.println(d);
        }
        if (d.isDirectory()) {
            File[] all = d.listFiles();
            for (File current : all) {
                searchDirectory(searchString, current);
            }
        }
    }

}
