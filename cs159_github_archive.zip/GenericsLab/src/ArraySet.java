import java.util.HashMap;

/**
 * A set type that works like an array with any reference data type.
 * 
 * @author Vanessa P
 * @version 11/27/23
 */

public class ArraySet<T> {
    private T[] universe;
    private boolean[] contains;
    private int size;

    /**
     * Explicit Value Constructor
     * 
     * @param elements the array of operable data types
     */
    public ArraySet(T[] elements) {
        if (elements == null) {
            this.universe = (T[]) new Object[0];
            this.contains = new boolean[0];
        } else {
            this.universe = (T[]) new Object[elements.length];
            this.contains = new boolean[elements.length];
            for (int i = 0; i < elements.length; i++) {
                T current = elements[i];
                this.universe[i] = current;
                this.contains[i] = false;
            }
        }
        this.size = 0;
    }

    /**
     * Adds a given value to the set.
     * 
     * @param value the object, of any reference type "T"
     * @return T/F if the type is operable
     */

    public boolean add(T value) {
        for (int i = 0; i < this.universe.length; i++) {
            if (this.universe[i].equals(value)) {
                if (this.contains[i] == false) {
                    this.contains[i] = true;
                    this.size++;
                }
                return true;
            }
        }
        return false;
    }

    /**
     * Removes the given value from the set
     * 
     * @param value the object, of any reference type "T"
     */

    public void remove(T value) {
        for (int i = 0; i < this.universe.length; i++) {
            if (this.universe[i].equals(value)) {
                if (this.contains[i] == true) {
                    this.contains[i] = false;
                    this.size--;
                }
            }
        }
    }

    /**
     * Determines if the given value is in the set.
     * 
     * @param value the object, of any reference type "T"
     * @return T/F if the object is in the set
     */
    public boolean contains(T value) {
        for (int i = 0; i < this.universe.length; i++) {
            if (this.universe[i].equals(value)) {
                if (this.contains[i] == true) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Denotes the number of items in this ArraySet.
     * 
     * @return the count of objects in the set
     */

    public int size() {
        return this.size;
    }

    /**
     * Clears this ArraySet, without changing operable types.
     */

    public void clear() {
        for (int i = 0; i < this.contains.length; i++) {
            this.contains[i] = false;
        }
        this.size = 0;
    }

    /**
     * Tests this ArraySet with another ArraySet for equality.
     * 
     * @param otherSet another ArraySet with elements of any reference type "T"
     * @return T/F if these objects are equal
     */

    public boolean equals(ArraySet<T> otherSet) {
        boolean b = true;
        if (this.contains != null) {
            for (int i = 0; i < this.contains.length; i++) {
                if (contains[i])
                    b = false;

            }
        }
        if (b) {
            if (otherSet.contains == null) {
                return true;
            }
            boolean e = true;
            for (int i = 0; i < otherSet.contains.length; i++) {
                if (otherSet.contains[i])
                    e = false;

            }
            return e;
        } else {
            if (this.size() != otherSet.size() || otherSet == null)
                return false;
            else {
                HashMap<T, Boolean> em = new HashMap<>();
                for (int i = 0; i < this.universe.length; i++) {
                    if (this.contains[i])
                        em.put(universe[i], contains[i]);

                }
                HashMap<T, Boolean> me = new HashMap<>();
                for (int i = 0; i < this.universe.length; i++) {
                    if (this.contains[i])
                        me.put(otherSet.universe[i], otherSet.contains[i]);

                }
                for (T key : em.keySet()) {
                    if (me.containsKey(key)) {
                        if (!me.get(key).equals(em.get(key)))
                            return false;

                    } else {
                        return false;
                    }
                }
                return true;
            }
        }
    }
}
